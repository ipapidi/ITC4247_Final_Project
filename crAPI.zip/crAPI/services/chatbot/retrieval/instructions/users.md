## Inbuilt User details to play around.

\```markdown
| Name  | Email                | Phone Number | Password    | Role            | SSN         |
|-------|----------------------|--------------|-------------|-----------------|-------------|
| Adam  | adam007@example.com  | 9876895423   | adam007!123 | ROLE_PREDEFINE  | 524-55-3232 |
| Pogba | pogba006@example.com | 9876570006   | pogba006!123| ROLE_PREDEFINE  | 680-82-6135 |
| Robot | robot001@example.com | 9876570001   | robot001!123| ROLE_PREDEFINE  | 159-10-9315 |
| Test  | test@example.com     | 9876540001   | Test!123    | ROLE_USER       | 027-01-7150 |
| Admin | admin@example.com    | 9010203040   | Admin!123   | ROLE_ADMIN      | 765-40-5663 |
\```
