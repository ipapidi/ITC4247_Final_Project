# crAPI Security Fuzzer

A comprehensive security fuzzer that tests crAPI endpoints against OWASP Top 10 vulnerabilities.

## Features

- **OWASP Top 10 Testing**: Tests against all major OWASP Top 10 (2021) vulnerabilities
- **Easy to Run**: Simple command-line interface
- **Visual Output**: Color-coded console output and HTML reports
- **Comprehensive Coverage**: Tests SQL injection, NoSQL injection, command injection, SSRF, broken authentication, and more

## Installation

1. Install Python 3.7 or higher
2. Install dependencies:
   ```bash
   pip install -r requirements-fuzzer.txt
   ```

## Usage

### Basic Usage

Run the fuzzer against the default localhost URL:
```bash
python3 fuzzer.py
```

The fuzzer will automatically:
- Run all security tests
- Generate an HTML report file
- Start a web interface on port 9999 (or next available port)
- Open the results in your default browser

### Custom URL

Test against a different URL:
```bash
python3 fuzzer.py -u http://192.168.1.100:8888
```

### Skip Authentication

Run tests without authentication:
```bash
python3 fuzzer.py --no-auth
```

### Disable Web Interface

If you don't want the web interface:
```bash
python3 fuzzer.py --no-web
```

### Custom Web Interface Port

Use a different port for the web interface:
```bash
python3 fuzzer.py --web-port 5001
```

### Comprehensive Testing (With AND Without Auth)

Run tests both with authentication and without authentication for complete coverage:
```bash
python3 fuzzer.py --all
```

This will:
- Run all tests WITH authentication (Phase 1)
- Run all tests WITHOUT authentication (Phase 2)
- Combine results from both phases
- Generate a combined HTML report: `fuzzer_report_all_TIMESTAMP.html`
- Show a comprehensive summary with all vulnerabilities found

### Command Line Options

```
-u, --url         Base URL of the API (default: http://localhost:8888)
-t, --timeout     Request timeout in seconds (default: 10)
--no-auth         Skip authentication
--no-web          Skip web interface
--web-port PORT   Port for web interface (default: 9999)
--all             Run tests both with AND without authentication
```

**Note**: The `--all` flag will run the complete test suite twice (once with auth, once without) and combine the results. This provides the most comprehensive security assessment but takes longer to complete.

## What It Tests

The fuzzer performs comprehensive security testing across multiple categories. Here's a detailed breakdown:

### 🔴 OWASP Top 10 (2021) Vulnerabilities

#### A01:2021 – Broken Access Control
- **IDOR (Insecure Direct Object Reference)**: Tests accessing resources with different IDs (other users' videos, orders, vehicles)
- **Unauthorized Access**: Tests protected endpoints without authentication
- **BOLA (Broken Object Level Authorization)**: Tests accessing objects belonging to other users
- **BFLA (Broken Function Level Authorization)**: Tests admin endpoints with regular user tokens
- **Path Traversal**: Tests directory traversal attacks (`../`, `..\\`, URL-encoded variants)

#### A03:2021 – Injection
- **SQL Injection**: Tests with classic SQL injection payloads (`' OR '1'='1`, `UNION SELECT`, etc.)
- **NoSQL Injection**: Tests MongoDB injection with operators (`$ne`, `$gt`, `$regex`, `$where`, etc.)
- **Command Injection**: Tests OS command injection (`;`, `|`, `&&`, backticks, `$(command)`)
- **Template Injection**: Tests server-side template injection

#### A04:2021 – Insecure Design
- **Mass Assignment**: Tests sending extra fields that shouldn't be processed (admin fields, internal properties)
- **Rate Limiting**: Tests for DoS vulnerabilities by making rapid requests
- **Business Logic Flaws**: Tests negative quantities, boundary values

#### A05:2021 – Security Misconfiguration
- **Exposed Files**: Tests for exposed sensitive files (`.env`, `.git/config`, `application.properties`, etc.)
- **Default Credentials**: Tests common default credentials
- **Missing Security Headers**: Checks for missing security headers (CSP, HSTS, X-Frame-Options, etc.)
- **Server Information Disclosure**: Checks for version information in headers

#### A07:2021 – Identification and Authentication Failures
- **Weak Authentication**: Tests authentication bypass attempts
- **Password Reset Vulnerabilities**: Tests password reset functionality for other users
- **JWT Vulnerabilities**: Tests JWT manipulation (algorithm confusion, invalid signature, JKU misuse, KID path traversal)
- **Session Management**: Tests session fixation and hijacking

#### A10:2021 – Server-Side Request Forgery (SSRF)
- **Internal Network Access**: Tests SSRF to internal IPs (`127.0.0.1`, `localhost`, `192.168.x.x`)
- **External URL Access**: Tests SSRF to external URLs (`http://www.google.com`, etc.)
- **Protocol Schemes**: Tests different protocols (`file://`, `gopher://`, `dict://`)

### 🎯 crAPI-Specific Challenge Tests

The fuzzer includes specific tests for all 15 documented crAPI challenges:

1. **Challenge 1 - BOLA (Vehicle Access)**: Tests accessing other users' vehicle locations via UUID manipulation
2. **Challenge 2 - BOLA (Mechanic Reports)**: Tests accessing mechanic reports with different report IDs
3. **Challenge 3 - Broken Auth**: Tests password reset for different users
4. **Challenge 4 & 5 - Excessive Data Exposure**: Tests endpoints that leak sensitive user data or internal video properties
5. **Challenge 6 - Rate Limiting**: Tests DoS via contact mechanic feature
6. **Challenge 7 - BFLA**: Tests deleting videos of other users via admin endpoints
7. **Challenge 8 & 9 - Mass Assignment (Orders)**: Tests manipulating order refunds with negative quantities
8. **Challenge 10 - Mass Assignment (Videos)**: Tests updating internal video properties
9. **Challenge 11 - SSRF**: Tests making crAPI call external URLs
10. **Challenge 12 - NoSQL Injection**: Tests getting free coupons via NoSQL injection
11. **Challenge 13 - SQL Injection**: Tests redeeming already claimed coupons via SQL injection
12. **Challenge 14 - Unauthenticated Access**: Tests endpoints that should require auth but don't
13. **Challenge 15 - JWT Vulnerabilities**: Tests all 4 JWT attack methods (algorithm confusion, invalid signature, JKU misuse, KID path traversal)

### 🔍 Extreme Input Testing

#### Type Confusion Attacks
- **String where Number Expected**: Tests passing "George" when numeric ID expected
- **Number where String Expected**: Tests passing numbers when strings expected
- **Boolean Confusion**: Tests passing strings/numbers when booleans expected
- **Array/Object Confusion**: Tests passing arrays where objects expected and vice versa
- **Null/Undefined Handling**: Tests with `null`, `undefined`, `NaN`, `Infinity`

#### Boundary Value Testing
- **Integer Boundaries**: Tests 32-bit and 64-bit integer limits (max/min values)
- **Negative Numbers**: Tests negative values where positive expected
- **Zero Values**: Tests zero where non-zero expected
- **Very Large Numbers**: Tests extremely large numbers (overflow conditions)
- **Floating Point Edge Cases**: Tests `inf`, `-inf`, `NaN`, very small decimals

#### Unexpected String Values
- **Empty Strings**: Tests with empty strings, whitespace-only
- **Control Characters**: Tests null bytes (`\x00`), newlines, tabs
- **Very Long Strings**: Tests with 10,000+ character strings
- **Special Characters**: Tests with path traversal, XSS, SQL injection strings
- **Unicode/Emoji**: Tests with Unicode characters, emojis, non-ASCII
- **Encoding Issues**: Tests URL encoding, hex encoding, Unicode encoding

#### Missing/Extra Fields
- **Missing Required Fields**: Tests endpoints with completely empty payloads
- **Extra Unexpected Fields**: Tests mass assignment with privileged fields
- **Duplicate Fields**: Tests with duplicate parameter names

### 🌐 Protocol-Level Testing

#### HTTP Method Testing
- **Method Override**: Tests all HTTP methods (GET, POST, PUT, DELETE, PATCH) on each endpoint
- **Unauthorized Methods**: Tests if endpoints accept methods they shouldn't
- **Method Confusion**: Tests if wrong methods return data when they shouldn't

#### Parameter Pollution (HPP)
- **Duplicate Query Parameters**: Tests `?id=1&id=2` scenarios
- **Multiple Values**: Tests if server processes multiple parameter values incorrectly
- **Parameter Injection**: Tests parameter pollution in query strings

#### Content Type Manipulation
- **Wrong Content Types**: Tests JSON endpoints with XML, form-encoded, plain text
- **Content-Type Confusion**: Tests if wrong content types are accepted
- **Deserialization Attacks**: Tests if different content types lead to deserialization vulnerabilities

#### Malformed Requests
- **Incomplete JSON**: Tests with missing closing braces, unclosed strings
- **Trailing Commas**: Tests JSON with trailing commas
- **Extra Braces**: Tests with extra opening/closing braces
- **Missing Values**: Tests with missing values in key-value pairs
- **URL-Encoded Instead of JSON**: Tests sending form data when JSON expected

### 📊 Comprehensive Endpoint Coverage

#### Automatic Spec-Based Testing
- **OpenAPI Spec Parsing**: Automatically discovers ALL endpoints from OpenAPI specification
- **Schema-Based Testing**: Extracts expected parameter types and tests with opposite types
- **Complete Coverage**: Tests every endpoint in the API, not just a hardcoded list
- **Parameter Type Extraction**: Identifies string, number, boolean, array, object parameters

#### Authenticated Endpoint Testing
- **Valid Authentication**: Tests protected endpoints with valid tokens
- **Invalid Tokens**: Tests with malformed, expired, or invalid tokens
- **Missing Authorization**: Tests protected endpoints without Authorization header
- **Token Manipulation**: Tests JWT token manipulation attacks

### 🔐 Information Disclosure Detection

#### Error Message Analysis
- **Stack Traces**: Detects stack traces in error responses
- **File Paths**: Detects exposed file system paths
- **Database Errors**: Detects database error messages
- **Framework Information**: Detects framework/version information

#### Sensitive Data Exposure
- **PII Leakage**: Detects personally identifiable information (emails, phone numbers, names)
- **Credentials**: Detects passwords, tokens, API keys in responses
- **Internal Data**: Detects internal properties, database IDs, UUIDs
- **Excessive Data**: Detects when more data is returned than necessary

#### Response Analysis
- **All Responses Checked**: Even "safe" responses are analyzed for information disclosure
- **Successful Responses**: Checks 200 OK responses for excessive data exposure
- **Error Responses**: Checks 4xx/5xx responses for sensitive information
- **Post-Processing**: Re-checks all results after initial testing

### ⚡ Performance & DoS Testing

#### Rate Limiting
- **Rapid Requests**: Makes 25-50 rapid requests to test rate limiting
- **DoS Detection**: Identifies endpoints vulnerable to DoS attacks
- **Contact Mechanic DoS**: Specific test for Challenge 6 (contact mechanic feature)

### 📋 Test Execution Order

1. **Authentication**: Creates test user and obtains auth token
2. **OWASP Top 10 Tests**: Runs all standard OWASP vulnerability tests
3. **Challenge-Specific Tests**: Runs all 15 crAPI challenge tests
4. **Unexpected Input Tests**: Tests with extreme inputs and type confusion
5. **Spec-Based Tests**: Tests all endpoints from OpenAPI spec
6. **Protocol Tests**: Tests parameter pollution, content types, malformed requests
7. **Post-Processing**: Re-analyzes all responses for information disclosure
8. **Report Generation**: Creates HTML report and web interface

## Output

### Console Output

The fuzzer provides color-coded console output:
- 🔴 **Red**: Vulnerable endpoints
- 🟢 **Green**: Safe endpoints
- ⚪ **Gray**: Failed/timeout requests

### Web Interface

After running, the fuzzer automatically starts a web interface (default: http://localhost:9999) that displays:
- **Real-time Statistics**: Total tests, vulnerable count, safe count
- **Severity Breakdown**: Vulnerabilities organized by severity level
- **Detailed Vulnerability List**: 
  - Endpoint and HTTP method
  - Vulnerability type and description
  - Payload used
  - Response details
  - Severity badges with color coding

The web interface features:
- Modern, responsive design
- Color-coded severity indicators
- Easy-to-read vulnerability cards
- Auto-refresh capability
- Mobile-friendly layout

### HTML Report

The fuzzer also generates a static HTML report file with:
- Summary statistics
- List of vulnerable endpoints
- Complete test results table
- Severity classifications

The report is saved as `fuzzer_report_YYYYMMDD_HHMMSS.html`

## Example Output

```
╔══════════════════════════════════════════════════════════════╗
║          OWASP Top 10 API Fuzzer for crAPI                   ║
║          Testing Security Vulnerabilities                    ║
╚══════════════════════════════════════════════════════════════╝

Base URL: http://localhost:8888
Started: 2024-01-15 10:30:00

[*] Authenticating...
✓ Authentication successful

[*] Testing A03:2021 – Injection (SQL Injection)
✗ [HIGH] POST   /identity/api/auth/login                    Status: 500 Time: 0.15s
      ⚠ POTENTIALLY VULNERABLE: SQL injection attempt with payload: ' OR '1'='1

...

TEST SUMMARY
======================================================================

Total Tests:     245
Vulnerable:      12
Safe:            233

Vulnerabilities by Severity:
  CRITICAL  : 2
  HIGH      : 5
  MEDIUM    : 5

✓ HTML report generated: fuzzer_report_20240115_103045.html
```

## Prerequisites

- crAPI must be running (see `instructions.md`)
- Python 3.7+
- `requests` library

## Notes

- The fuzzer creates a test user account for authentication
- Some tests may take several minutes to complete
- Rate limiting is built-in to avoid overwhelming the server
- The fuzzer uses heuristic detection - results should be manually verified

## Troubleshooting

**Connection refused errors:**
- Ensure crAPI is running: `docker compose ps` in `deploy/docker`
- Check the URL: `python3 fuzzer.py -u http://localhost:8888`

**Authentication failures:**
- The fuzzer will continue with unauthenticated tests if auth fails
- Use `--no-auth` to skip authentication entirely

**Timeout errors:**
- Increase timeout: `python3 fuzzer.py -t 30`

## Disclaimer

This fuzzer is for educational and security testing purposes only. Only use it on systems you own or have explicit permission to test.

