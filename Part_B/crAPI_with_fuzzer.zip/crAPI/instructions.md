# Step-by-Step Guide: Running crAPI with Docker

This guide will walk you through running crAPI (Completely Ridiculous API) using Docker and Docker Compose.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Option 1: Using Prebuilt Images (Recommended)](#option-1-using-prebuilt-images-recommended)
3. [Option 2: Building from Source](#option-2-building-from-source)
4. [Starting the Services](#starting-the-services)
5. [Accessing the Application](#accessing-the-application)
6. [Stopping the Services](#stopping-the-services)
7. [Troubleshooting](#troubleshooting)

---

## Prerequisites

### Step 1: Install Docker
1. **For Linux:**
   - Visit [Docker Installation Guide](https://docs.docker.com/engine/install/)
   - Follow the instructions for your Linux distribution
   - Or install using package manager:
     ```bash
     # Ubuntu/Debian
     sudo apt-get update
     sudo apt-get install docker.io docker-compose-plugin
     ```

2. **For macOS:**
   - Download and install [Docker Desktop for Mac](https://www.docker.com/products/docker-desktop)
   - Or install via Homebrew:
     ```bash
     brew install --cask docker
     ```

3. **For Windows:**
   - Download and install [Docker Desktop for Windows](https://www.docker.com/products/docker-desktop)

### Step 2: Verify Docker Installation
Open a terminal/command prompt and run:
```bash
docker --version
docker compose version
```

**Important:** Docker Compose version should be `1.27.0` or above. If you see an older version, you need to upgrade.

### Step 3: Start Docker
- **Linux:** Start Docker service:
  ```bash
  sudo systemctl start docker
  sudo systemctl enable docker
  ```
- **macOS/Windows:** Launch Docker Desktop application

### Step 4: Verify Docker is Running
```bash
docker ps
```
If this command runs without errors, Docker is running correctly.

---

## Option 1: Using Prebuilt Images (Recommended)

This is the fastest way to get crAPI running. The prebuilt images are available on Docker Hub.

### Step 1: Download the Repository

**For Linux/macOS:**
```bash
# Download the latest stable version
curl -o /tmp/crapi.zip https://github.com/OWASP/crAPI/archive/refs/heads/main.zip

# Extract the archive
unzip /tmp/crapi.zip -d /tmp

# Navigate to the docker directory
cd /tmp/crAPI-main/deploy/docker
```

**For Windows (PowerShell):**
```powershell
# Download the latest stable version
curl.exe -o crapi.zip https://github.com/OWASP/crAPI/archive/refs/heads/main.zip

# Extract the archive (requires 7-Zip or similar)
Expand-Archive -Path crapi.zip -DestinationPath .

# Navigate to the docker directory
cd crAPI-main\deploy\docker
```

**Alternative: Clone with Git**
```bash
git clone https://github.com/OWASP/crAPI.git
cd crAPI/deploy/docker
```

### Step 2: Pull Prebuilt Images
```bash
docker compose pull
```

This will download all required Docker images from Docker Hub. This may take a few minutes depending on your internet connection.

### Step 3: Start the Services
```bash
docker compose -f docker-compose.yml --compatibility up -d
```

The `-d` flag runs containers in detached mode (in the background).

**Note:** The first time you run this, it may take several minutes as Docker sets up volumes and initializes databases.

### Step 4: Verify Services are Running
```bash
docker compose ps
```

You should see all services with status "Up" or "Up (healthy)".

---

## Option 2: Building from Source

If you want to build the Docker images yourself from source code:

### Step 1: Clone the Repository

**For Linux/macOS:**
```bash
git clone https://github.com/OWASP/crAPI.git
cd crAPI
```

**For Windows:**
```bash
git clone https://github.com/OWASP/crAPI.git --config core.autocrlf=input
cd crAPI
```

### Step 2: Build All Docker Images

**For Linux/macOS:**
```bash
cd deploy/docker
./build-all.sh
```

**For Windows:**
```cmd
cd deploy\docker
call build-all.bat
```

This will build Docker images for all services:
- `crapi-identity`
- `crapi-community`
- `crapi-workshop`
- `crapi-web`
- `crapi-gateway-service`
- `crapi-mailhog`

**Note:** Building from source can take 10-30 minutes depending on your system.

### Step 3: Start the Services
```bash
docker compose -f docker-compose.yml --compatibility up -d
```

---

## Starting the Services

### Basic Start
```bash
cd deploy/docker
docker compose -f docker-compose.yml --compatibility up -d
```

### Start with Custom Configuration

You can override environment variables when starting:

**Expose to all network interfaces (not just localhost):**
```bash
LISTEN_IP="0.0.0.0" docker compose -f docker-compose.yml --compatibility up -d
```

**Start in foreground (to see logs):**
```bash
docker compose -f docker-compose.yml --compatibility up
```

**Start specific services only:**
```bash
docker compose -f docker-compose.yml --compatibility up -d postgresdb mongodb mailhog
```

### Check Service Logs
```bash
# View all logs
docker compose logs

# View logs for a specific service
docker compose logs crapi-identity

# Follow logs in real-time
docker compose logs -f
```

### Check Service Status
```bash
docker compose ps
```

All services should show as "Up" or "Up (healthy)".

---

## Accessing the Application

### Main Application
Once all services are running, access crAPI at:
- **Web Interface:** http://localhost:8888
- **Alternative Port:** http://localhost:30080

### MailHog (Email Testing)
All emails sent by crAPI are captured by MailHog. Access the MailHog web interface at:
- **MailHog UI:** http://localhost:8025

### API Gateway
The API gateway is available at:
- **HTTPS:** https://api.mypremiumdealership.com (requires hostname configuration)
- **HTTP Port:** http://localhost:8443

### Service Health Checks
You can check individual service health:
```bash
# Check all services
docker compose ps

# Check specific service logs
docker compose logs crapi-identity
docker compose logs crapi-community
docker compose logs crapi-workshop
docker compose logs crapi-web
```

---

## Stopping the Services

### Stop Services (Keep Containers)
```bash
cd deploy/docker
docker compose -f docker-compose.yml stop
```

### Stop and Remove Containers
```bash
cd deploy/docker
docker compose -f docker-compose.yml --compatibility down
```

### Stop and Remove Containers + Volumes (Clean Slate)
**Warning:** This will delete all data including databases!
```bash
cd deploy/docker
docker compose -f docker-compose.yml --compatibility down -v
```

### Remove Images (Optional)
If you want to free up disk space:
```bash
# Remove all crAPI images
docker images | grep crapi | awk '{print $3}' | xargs docker rmi

# Or remove specific image
docker rmi crapi/crapi-identity:latest
```

---

## Troubleshooting

### Issue 1: Docker Compose Command Not Found

**Error:**
```
Command 'docker-compose' not found
```

**Solution:**
- Use `docker compose` (with space) instead of `docker-compose` (with hyphen)
- Modern Docker installations include compose as a plugin

### Issue 2: Invalid Interpolation Format Error

**Error:**
```
ERROR: Invalid interpolation format for "crapi-identity" option in service "services"
```

**Solution:**
- Your Docker Compose version is too old (needs 1.27.0+)
- Upgrade Docker Compose:
  ```bash
  # Linux
  sudo curl -SL https://github.com/docker/compose/releases/download/v2.11.2/docker-compose-linux-x86_64 -o /usr/local/bin/docker-compose
  sudo chmod +x /usr/local/bin/docker-compose
  
  # macOS (Intel)
  sudo curl -SL https://github.com/docker/compose/releases/download/v2.11.2/docker-compose-darwin-x86_64 -o /usr/local/bin/docker-compose
  sudo chmod +x /usr/local/bin/docker-compose
  
  # macOS (M1/Apple Silicon)
  sudo curl -SL https://github.com/docker/compose/releases/download/v2.11.2/docker-compose-darwin-aarch64 -o /usr/local/bin/docker-compose
  sudo chmod +x /usr/local/bin/docker-compose
  ```

### Issue 3: Port Already in Use

**Error:**
```
Error: bind: address already in use
```

**Solution:**
- Check what's using the port:
  ```bash
  # Linux/macOS
  lsof -i :8888
  # or
  netstat -an | grep 8888
  
  # Windows
  netstat -ano | findstr :8888
  ```
- Stop the conflicting service or change the port in `docker-compose.yml`

### Issue 4: Services Not Starting

**Check service logs:**
```bash
docker compose logs
```

**Check service status:**
```bash
docker compose ps
```

**Restart a specific service:**
```bash
docker compose restart crapi-identity
```

**Restart all services:**
```bash
docker compose restart
```

### Issue 5: Database Connection Issues

**Symptoms:** Services fail to connect to PostgreSQL or MongoDB

**Solution:**
1. Ensure databases are healthy:
   ```bash
   docker compose ps postgresdb mongodb
   ```
2. Wait for databases to be ready (they may take 30-60 seconds to initialize)
3. Check database logs:
   ```bash
   docker compose logs postgresdb
   docker compose logs mongodb
   ```

### Issue 6: Out of Disk Space

**Check Docker disk usage:**
```bash
docker system df
```

**Clean up unused resources:**
```bash
# Remove unused containers, networks, images
docker system prune

# Remove unused volumes (be careful!)
docker volume prune
```

### Issue 7: Permission Denied Errors (Linux)

**Error:**
```
permission denied while trying to connect to the Docker daemon socket
```

**Solution:**
```bash
# Add your user to docker group
sudo usermod -aG docker $USER

# Log out and log back in, or run:
newgrp docker
```

---

## Additional Configuration

### Custom JWKS Keys
To use custom JWKS keys, place a `jwks.json` file in the `deploy/docker/keys/` directory before starting services.

### Environment Variables
You can create a `.env` file in `deploy/docker/` to set custom environment variables:
```bash
VERSION=latest
LISTEN_IP=127.0.0.1
LOG_LEVEL=INFO
TLS_ENABLED=false
```

### Expose Services to Network
To make crAPI accessible from other machines on your network:
```bash
LISTEN_IP="0.0.0.0" docker compose -f docker-compose.yml --compatibility up -d
```

Then access via your machine's IP address: `http://YOUR_IP:8888`

---

## Service Architecture

crAPI consists of the following services:

1. **crapi-identity** - Authentication and user management service
2. **crapi-community** - Community posts and comments service
3. **crapi-workshop** - Workshop/mechanic service
4. **crapi-web** - Web frontend (nginx)
5. **api.mypremiumdealership.com** - API Gateway
6. **postgresdb** - PostgreSQL database
7. **mongodb** - MongoDB database
8. **mailhog** - Email testing service

---

## Next Steps

- Visit http://localhost:8888 to start using crAPI
- Check http://localhost:8025 to view emails sent by the application
- Review the [challenges documentation](docs/challenges.md) to learn about API security vulnerabilities
- Explore the [API endpoints](openapi-spec/crapi-openapi-spec.json) using the OpenAPI specification

---

## Getting Help

If you encounter issues not covered in this guide:
1. Check the [Troubleshooting Guide](docs/troubleshooting.md)
2. Review service logs: `docker compose logs`
3. Check [GitHub Issues](https://github.com/OWASP/crAPI/issues)
4. Create a new issue with details about your problem

